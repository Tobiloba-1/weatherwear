<?php
session_start();
include "../database/db.php";

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin' || !isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch admin details
$id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Fetch total users count
$userQuery = $conn->query("SELECT COUNT(*) AS total_users FROM users");
$userCount = $userQuery->fetch_assoc();
$totalUsers = $userCount['total_users'];

// Fetch admin count
$adminQuery = $conn->query("SELECT COUNT(*) AS total_admins FROM users WHERE role = 'admin'");
$adminCount = $adminQuery->fetch_assoc();
$totalAdmins = $adminCount['total_admins'];

// Fetch student count
$studentQuery = $conn->query("SELECT COUNT(*) AS total_students FROM users WHERE role = 'student'");
$studentCount = $studentQuery->fetch_assoc();
$totalStudents = $studentCount['total_students'];

// Fetch total feedback count
$feedbackCountQuery = $conn->query("SELECT COUNT(*) AS total_feedbacks FROM feedback");
$feedbackCountResult = $feedbackCountQuery->fetch_assoc();
$totalFeedbacks = $feedbackCountResult['total_feedbacks'];

// Fetch latest feedback records (limit to 10)
$feedbackStmt = $conn->prepare("SELECT * FROM feedback ORDER BY submitted_at DESC LIMIT 10");
$feedbackStmt->execute();
$feedbackResult = $feedbackStmt->get_result();

// Fetch recent users (limit to 5)
$recentUsersQuery = $conn->query("SELECT fullname, email, role, created_at FROM users ORDER BY created_at DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .stat-card {
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .table-row {
            transition: background-color 0.2s;
        }

        .table-row:hover {
            background-color: #f9fafb;
        }

        .activity-item {
            transition: all 0.2s;
        }

        .activity-item:hover {
            background-color: #f3f4f6;
            transform: translateX(5px);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }

        .chart-pulse {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.7;
            }
        }

        /* Sidebar collapse styles */
        aside {
            transition: margin-left 0.3s ease;
        }
        
        aside.collapsed {
            margin-left: -16rem;
        }
        
        main {
            transition: margin-left 0.3s ease;
        }
        
        main.expanded {
            margin-left: 0 !important;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans antialiased">

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white shadow-2xl fixed h-full z-40">
            <div class="p-6 border-b border-blue-700">
                <h2 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-shield-alt mr-3"></i>
                    Admin Panel
                </h2>
            </div>
            <nav class="mt-6">
                <ul class="space-y-2 px-4">
                    <li>
                        <a href="dashboard.php" class="flex items-center p-3 rounded-lg bg-blue-700 transition">
                            <i class="fas fa-chart-line w-6"></i>
                            <span class="ml-3 font-semibold">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-users w-6"></i>
                            <span class="ml-3">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="feedback.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-comments w-6"></i>
                            <span class="ml-3">Feedback</span>
                        </a>
                    </li>
                    <li>
                        <a href="settings.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-cog w-6"></i>
                            <span class="ml-3">Settings</span>
                        </a>
                    </li>
                    <li class="pt-4 mt-4 border-t border-blue-700">
                        <a href="../auth/logout.php" class="flex items-center p-3 rounded-lg hover:bg-red-600 transition">
                            <i class="fas fa-sign-out-alt w-6"></i>
                            <span class="ml-3">Log Out</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main id="mainContent" class="flex-1 overflow-y-auto ml-64">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200">
                <div class="px-8 py-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <button id="toggleSidebar" class="mr-4 text-gray-600 hover:text-gray-900 focus:outline-none">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900">
                                    Welcome back, <?php echo htmlspecialchars($admin['fullname']); ?>! 👋
                                </h1>
                                <p class="text-gray-600 mt-1">Here's what's happening with your platform today</p>
                            </div>
                        </div>
                        <div class="flex items-center space-x-4">
                            <div class="text-right">
                                <p class="text-sm text-gray-600">Logged in as</p>
                                <p class="text-sm font-semibold text-gray-900"><?php echo htmlspecialchars($admin['fullname']); ?></p>
                            </div>
                            <div class="h-12 w-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                                <?php echo strtoupper(substr($admin['fullname'], 0, 1)); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <div class="p-8">
                <!-- Statistics Cards -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <!-- Total Users Card -->
                    <div class="stat-card bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white fade-in">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-blue-100 text-sm font-medium uppercase">Total Users</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $totalUsers; ?></h3>
                                <p class="text-blue-100 text-sm mt-2">All registered users</p>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-users text-3xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Administrators Card -->
                    <div class="stat-card bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-6 text-white fade-in" style="animation-delay: 0.1s;">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-purple-100 text-sm font-medium uppercase">Administrators</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $totalAdmins; ?></h3>
                                <p class="text-purple-100 text-sm mt-2">Active admins</p>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-user-shield text-3xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Students Card -->
                    <div class="stat-card bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white fade-in" style="animation-delay: 0.2s;">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-green-100 text-sm font-medium uppercase">Students</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $totalStudents; ?></h3>
                                <p class="text-green-100 text-sm mt-2">Active students</p>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-graduation-cap text-3xl"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Total Feedback Card -->
                    <div class="stat-card bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl shadow-lg p-6 text fade-in" style="animation-delay: 0.3s;">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-orange-100 text-sm font-medium uppercase">Total Feedback</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $totalFeedbacks; ?></h3>
                                <p class="text-orange-100 text-sm mt-2">User responses</p>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-comments text-3xl"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Two Column Layout -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <!-- Latest Feedback Section (2 columns) -->
                    <div class="lg:col-span-2">
                        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
                                <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                    <i class="fas fa-comment-dots mr-2 text-blue-600"></i>
                                    Latest Feedback
                                </h2>
                                <p class="text-sm text-gray-600 mt-1">Recent user feedback submissions</p>
                            </div>
                            
                            <div class="overflow-x-auto max-h-96 overflow-y-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50 sticky top-0">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">#</th>
                                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Email</th>
                                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Feedback</th>
                                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php
                                        $count = 1;
                                        if ($feedbackResult->num_rows > 0) {
                                            while ($row = $feedbackResult->fetch_assoc()) {
                                                echo "<tr class='table-row'>";
                                                echo "<td class='px-6 py-4 text-sm text-gray-900 font-medium'>$count</td>";
                                                echo "<td class='px-6 py-4'>";
                                                echo "  <div class='flex items-center'>";
                                                echo "    <div class='flex-shrink-0 h-8 w-8 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full flex items-center justify-center text-white font-semibold text-xs'>";
                                                echo "      " . strtoupper(substr($row['fullname'], 0, 1)) . "";
                                                echo "    </div>";
                                                echo "    <div class='ml-3'>";
                                                echo "      <div class='text-sm font-medium text-gray-900'>" . htmlspecialchars($row['fullname']) . "</div>";
                                                echo "    </div>";
                                                echo "  </div>";
                                                echo "</td>";
                                                echo "<td class='px-6 py-4 text-sm text-gray-700'>" . htmlspecialchars($row['email']) . "</td>";
                                                echo "<td class='px-6 py-4 text-sm text-gray-600'>";
                                                echo "  <div class='max-w-xs truncate' title='" . htmlspecialchars($row['feedback']) . "'>";
                                                echo "    " . htmlspecialchars(substr($row['feedback'], 0, 50)) . (strlen($row['feedback']) > 50 ? '...' : '');
                                                echo "  </div>";
                                                echo "</td>";
                                                echo "<td class='px-6 py-4 text-sm text-gray-600'>" . date('M d, Y', strtotime($row['submitted_at'])) . "</td>";
                                                echo "</tr>";
                                                $count++;
                                            }
                                        } else {
                                            echo "<tr><td colspan='5' class='px-6 py-8 text-center'>";
                                            echo "  <div class='text-gray-400'>";
                                            echo "    <i class='fas fa-inbox text-4xl mb-2'></i>";
                                            echo "    <p class='text-lg'>No feedback yet</p>";
                                            echo "  </div>";
                                            echo "</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                                <a href="feedback.php" class="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center justify-end">
                                    View all feedback
                                    <i class="fas fa-arrow-right ml-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity Sidebar (1 column) -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                            <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-green-50 to-blue-50">
                                <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                    <i class="fas fa-clock mr-2 text-green-600"></i>
                                    Recent Users
                                </h2>
                                <p class="text-sm text-gray-600 mt-1">Latest user registrations</p>
                            </div>
                            
                            <div class="p-4 max-h-96 overflow-y-auto">
                                <?php
                                if ($recentUsersQuery->num_rows > 0) {
                                    while ($user = $recentUsersQuery->fetch_assoc()) {
                                        $roleColor = $user['role'] === 'admin' ? 'purple' : 'green';
                                        $roleIcon = $user['role'] === 'admin' ? 'fa-user-shield' : 'fa-user';
                                        
                                        echo "<div class='activity-item p-3 rounded-lg mb-3 border border-gray-100'>";
                                        echo "  <div class='flex items-start'>";
                                        echo "    <div class='flex-shrink-0 h-10 w-10 bg-gradient-to-br from-$roleColor-400 to-$roleColor-500 rounded-full flex items-center justify-center text-white font-semibold'>";
                                        echo "      " . strtoupper(substr($user['fullname'], 0, 1)) . "";
                                        echo "    </div>";
                                        echo "    <div class='ml-3 flex-1'>";
                                        echo "      <div class='flex items-center justify-between'>";
                                        echo "        <p class='text-sm font-medium text-gray-900'>" . htmlspecialchars($user['fullname']) . "</p>";
                                        echo "        <span class='text-xs px-2 py-1 rounded-full bg-$roleColor-100 text-$roleColor-800'>";
                                        echo "          <i class='fas $roleIcon mr-1'></i>" . ucfirst($user['role']);
                                        echo "        </span>";
                                        echo "      </div>";
                                        echo "      <p class='text-xs text-gray-600 mt-1'>" . htmlspecialchars($user['email']) . "</p>";
                                        echo "      <p class='text-xs text-gray-500 mt-1'>";
                                        echo "        <i class='fas fa-calendar-alt mr-1'></i>" . date('M d, Y', strtotime($user['created_at']));
                                        echo "      </p>";
                                        echo "    </div>";
                                        echo "  </div>";
                                        echo "</div>";
                                    }
                                } else {
                                    echo "<div class='text-center py-8 text-gray-400'>";
                                    echo "  <i class='fas fa-user-plus text-4xl mb-2'></i>";
                                    echo "  <p>No recent users</p>";
                                    echo "</div>";
                                }
                                ?>
                            </div>
                            
                            <div class="px-6 py-4 bg-gray-50 border-t border-gray-200">
                                <a href="users.php" class="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center justify-end">
                                    View all users
                                    <i class="fas fa-arrow-right ml-2"></i>
                                </a>
                            </div>
                        </div>

                        <!-- Quick Stats Card -->
                        <div class="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg p-6 text-white mt-6">
                            <h3 class="text-lg font-semibold mb-4 flex items-center">
                                <i class="fas fa-chart-pie mr-2"></i>
                                Quick Overview
                            </h3>
                            <div class="space-y-3">
                                <div class="flex justify-between items-center">
                                    <span class="text-indigo-100">User Growth</span>
                                    <span class="font-bold"><?php echo $totalUsers; ?> total</span>
                                </div>
                                <div class="h-2 bg-white bg-opacity-20 rounded-full overflow-hidden">
                                    <div class="h-full bg-white rounded-full chart-pulse" style="width: <?php echo ($totalStudents / max($totalUsers, 1)) * 100; ?>%"></div>
                                </div>
                                <div class="flex justify-between items-center pt-2">
                                    <span class="text-indigo-100">Feedback Rate</span>
                                    <span class="font-bold"><?php echo $totalFeedbacks; ?> responses</span>
                                </div>
                                <div class="h-2 bg-white bg-opacity-20 rounded-full overflow-hidden">
                                    <div class="h-full bg-white rounded-full chart-pulse" style="width: <?php echo min(($totalFeedbacks / max($totalUsers, 1)) * 100, 100); ?>%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Sidebar toggle functionality
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const toggleBtn = document.getElementById('toggleSidebar');

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        });
    </script>
</body>
</html>