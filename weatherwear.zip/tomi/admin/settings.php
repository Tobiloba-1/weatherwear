<?php
session_start();
include "../database/db.php";

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin' || !isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Fetch admin details
$id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

// Handle profile update
if (isset($_POST['update_profile'])) {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    
    $update_query = "UPDATE users SET fullname = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssi", $fullname, $email, $id);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Profile updated successfully!";
        header("Location: settings.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Failed to update profile.";
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verify current password
    if (password_verify($current_password, $admin['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 6) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $update_query = "UPDATE users SET password = ? WHERE id = ?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("si", $hashed_password, $id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Password changed successfully!";
                    header("Location: settings.php");
                    exit();
                } else {
                    $_SESSION['error_message'] = "Failed to change password.";
                }
            } else {
                $_SESSION['error_message'] = "New password must be at least 6 characters.";
            }
        } else {
            $_SESSION['error_message'] = "New passwords do not match.";
        }
    } else {
        $_SESSION['error_message'] = "Current password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .alert {
            animation: slideDown 0.3s;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .settings-card {
            transition: all 0.3s;
        }

        .settings-card:hover {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
        }

        .tab-button {
            transition: all 0.3s;
        }

        .tab-button.active {
            background: linear-gradient(to right, #3b82f6, #8b5cf6);
            color: white;
        }

        .tab-content {
            display: none;
            animation: fadeIn 0.4s;
        }

        .tab-content.active {
            display: block;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Sidebar collapse styles */
        aside {
            transition: margin-left 0.3s ease;
        }
        
        aside.collapsed {
            margin-left: -16rem;
        }
        
        main {
            transition: margin-left 0.3s ease;
        }
        
        main.expanded {
            margin-left: 0 !important;
        }

        .input-field:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50 font-sans antialiased">

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white shadow-2xl fixed h-full z-40">
            <div class="p-6 border-b border-blue-700">
                <h2 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-shield-alt mr-3"></i>
                    Admin Panel
                </h2>
            </div>
            <nav class="mt-6">
                <ul class="space-y-2 px-4">
                    <li>
                        <a href="../admin/" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-chart-line w-6"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-users w-6"></i>
                            <span class="ml-3">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="feedback.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-comments w-6"></i>
                            <span class="ml-3">Feedback</span>
                        </a>
                    </li>
                    <li>
                        <a href="settings.php" class="flex items-center p-3 rounded-lg bg-blue-700 transition">
                            <i class="fas fa-cog w-6"></i>
                            <span class="ml-3 font-semibold">Settings</span>
                        </a>
                    </li>
                    <li class="pt-4 mt-4 border-t border-blue-700">
                        <a href="../auth/logout.php" class="flex items-center p-3 rounded-lg hover:bg-red-600 transition">
                            <i class="fas fa-sign-out-alt w-6"></i>
                            <span class="ml-3">Log Out</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main id="mainContent" class="flex-1 overflow-y-auto ml-64">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200">
                <div class="px-8 py-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <button id="toggleSidebar" class="mr-4 text-gray-600 hover:text-gray-900 focus:outline-none">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900">Settings</h1>
                                <p class="text-gray-600 mt-1">Manage your account settings and preferences</p>
                            </div>
                        </div>
                        <div class="flex items-center space-x-4">
                            <div class="h-12 w-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                                <?php echo strtoupper(substr($admin['fullname'], 0, 1)); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <div class="p-8">
                <!-- Alert Messages -->
                <?php if (isset($_SESSION['success_message'])): ?>
                    <div class="alert bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg shadow">
                        <div class="flex items-center">
                            <i class="fas fa-check-circle mr-3"></i>
                            <span><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="alert bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg shadow">
                        <div class="flex items-center">
                            <i class="fas fa-exclamation-circle mr-3"></i>
                            <span><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    <!-- Sidebar Tabs -->
                    <div class="lg:col-span-1">
                        <div class="bg-white rounded-xl shadow-lg p-4">
                            <h3 class="text-sm font-semibold text-gray-500 uppercase mb-3 px-2">Settings Menu</h3>
                            <nav class="space-y-2">
                                <button onclick="switchTab('profile')" class="tab-button active w-full text-left px-4 py-3 rounded-lg flex items-center">
                                    <i class="fas fa-user-circle w-6 mr-3"></i>
                                    <span>Profile</span>
                                </button>
                                <button onclick="switchTab('security')" class="tab-button w-full text-left px-4 py-3 rounded-lg flex items-center hover:bg-gray-100">
                                    <i class="fas fa-lock w-6 mr-3"></i>
                                    <span>Security</span>
                                </button>
                                <button onclick="switchTab('account')" class="tab-button w-full text-left px-4 py-3 rounded-lg flex items-center hover:bg-gray-100">
                                    <i class="fas fa-user-cog w-6 mr-3"></i>
                                    <span>Account Info</span>
                                </button>
                            </nav>
                        </div>

                        <!-- Quick Stats Card -->
                        <div class="bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl shadow-lg p-6 text-white mt-6">
                            <div class="flex items-center mb-4">
                                <i class="fas fa-info-circle text-2xl mr-3"></i>
                                <h3 class="text-lg font-semibold">Quick Info</h3>
                            </div>
                            <div class="space-y-3 text-sm">
                                <div class="flex justify-between">
                                    <span class="text-blue-100">Role:</span>
                                    <span class="font-semibold"><?php echo ucfirst($admin['role']); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-blue-100">Joined:</span>
                                    <span class="font-semibold"><?php echo date('M Y', strtotime($admin['created_at'])); ?></span>
                                </div>
                                <div class="flex justify-between">
                                    <span class="text-blue-100">Status:</span>
                                    <span class="font-semibold flex items-center">
                                        <span class="h-2 w-2 bg-green-400 rounded-full mr-2"></span>
                                        Active
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Main Content Area -->
                    <div class="lg:col-span-3">
                        <!-- Profile Tab -->
                        <div id="profile-tab" class="tab-content active">
                            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                                <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-purple-50">
                                    <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                        <i class="fas fa-user-circle mr-2 text-blue-600"></i>
                                        Profile Information
                                    </h2>
                                    <p class="text-sm text-gray-600 mt-1">Update your personal information</p>
                                </div>

                                <form action="settings.php" method="POST" class="p-6">
                                    <div class="flex items-center mb-8">
                                        <div class="h-24 w-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-3xl">
                                            <?php echo strtoupper(substr($admin['fullname'], 0, 1)); ?>
                                        </div>
                                        <div class="ml-6">
                                            <h3 class="text-xl font-semibold text-gray-900"><?php echo htmlspecialchars($admin['fullname']); ?></h3>
                                            <p class="text-gray-600"><?php echo htmlspecialchars($admin['email']); ?></p>
                                            <span class="inline-block mt-2 px-3 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                                                <i class="fas fa-user-shield mr-1"></i><?php echo ucfirst($admin['role']); ?>
                                            </span>
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div>
                                            <label for="fullname" class="block text-sm font-medium text-gray-700 mb-2">
                                                <i class="fas fa-user mr-1 text-gray-400"></i> Full Name
                                            </label>
                                            <input type="text" id="fullname" name="fullname" 
                                                   value="<?php echo htmlspecialchars($admin['fullname']); ?>"
                                                   class="input-field w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none transition" 
                                                   required>
                                        </div>

                                        <div>
                                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">
                                                <i class="fas fa-envelope mr-1 text-gray-400"></i> Email Address
                                            </label>
                                            <input type="email" id="email" name="email" 
                                                   value="<?php echo htmlspecialchars($admin['email']); ?>"
                                                   class="input-field w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none transition" 
                                                   required>
                                        </div>
                                    </div>

                                    <div class="mt-6 flex justify-end">
                                        <button type="submit" name="update_profile" 
                                                class="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-medium transition flex items-center">
                                            <i class="fas fa-save mr-2"></i>
                                            Save Changes
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Security Tab -->
                        <div id="security-tab" class="tab-content">
                            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                                <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-red-50 to-orange-50">
                                    <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                        <i class="fas fa-lock mr-2 text-red-600"></i>
                                        Security Settings
                                    </h2>
                                    <p class="text-sm text-gray-600 mt-1">Change your password and secure your account</p>
                                </div>

                                <form action="settings.php" method="POST" class="p-6">
                                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-6 rounded">
                                        <div class="flex items-center">
                                            <i class="fas fa-exclamation-triangle text-yellow-600 mr-3"></i>
                                            <p class="text-sm text-yellow-700">
                                                Make sure your password is at least 6 characters long and includes a mix of letters and numbers.
                                            </p>
                                        </div>
                                    </div>

                                    <div class="space-y-6">
                                        <div>
                                            <label for="current_password" class="block text-sm font-medium text-gray-700 mb-2">
                                                <i class="fas fa-key mr-1 text-gray-400"></i> Current Password
                                            </label>
                                            <input type="password" id="current_password" name="current_password" 
                                                   class="input-field w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none transition" 
                                                   required>
                                        </div>

                                        <div>
                                            <label for="new_password" class="block text-sm font-medium text-gray-700 mb-2">
                                                <i class="fas fa-lock mr-1 text-gray-400"></i> New Password
                                            </label>
                                            <input type="password" id="new_password" name="new_password" 
                                                   class="input-field w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none transition" 
                                                   required minlength="6">
                                        </div>

                                        <div>
                                            <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-2">
                                                <i class="fas fa-check-circle mr-1 text-gray-400"></i> Confirm New Password
                                            </label>
                                            <input type="password" id="confirm_password" name="confirm_password" 
                                                   class="input-field w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none transition" 
                                                   required minlength="6">
                                        </div>
                                    </div>

                                    <div class="mt-6 flex justify-end">
                                        <button type="submit" name="change_password" 
                                                class="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white px-6 py-3 rounded-lg font-medium transition flex items-center">
                                            <i class="fas fa-shield-alt mr-2"></i>
                                            Change Password
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Account Info Tab -->
                        <div id="account-tab" class="tab-content">
                            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                                <div class="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-green-50 to-blue-50">
                                    <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                        <i class="fas fa-user-cog mr-2 text-green-600"></i>
                                        Account Information
                                    </h2>
                                    <p class="text-sm text-gray-600 mt-1">View your account details</p>
                                </div>

                                <div class="p-6">
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                        <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div class="flex items-center mb-2">
                                                <i class="fas fa-id-badge text-blue-600 mr-2"></i>
                                                <h3 class="text-sm font-semibold text-gray-700">User ID</h3>
                                            </div>
                                            <p class="text-lg font-medium text-gray-900">#<?php echo $admin['id']; ?></p>
                                        </div>

                                        <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div class="flex items-center mb-2">
                                                <i class="fas fa-user-tag text-purple-600 mr-2"></i>
                                                <h3 class="text-sm font-semibold text-gray-700">Account Role</h3>
                                            </div>
                                            <p class="text-lg font-medium text-gray-900"><?php echo ucfirst($admin['role']); ?></p>
                                        </div>

                                        <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div class="flex items-center mb-2">
                                                <i class="fas fa-calendar-plus text-green-600 mr-2"></i>
                                                <h3 class="text-sm font-semibold text-gray-700">Account Created</h3>
                                            </div>
                                            <p class="text-lg font-medium text-gray-900"><?php echo date('F d, Y', strtotime($admin['created_at'])); ?></p>
                                        </div>

                                        <div class="bg-gray-50 rounded-lg p-4 border border-gray-200">
                                            <div class="flex items-center mb-2">
                                                <i class="fas fa-check-circle text-green-600 mr-2"></i>
                                                <h3 class="text-sm font-semibold text-gray-700">Account Status</h3>
                                            </div>
                                            <p class="text-lg font-medium text-green-600 flex items-center">
                                                <span class="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
                                                Active
                                            </p>
                                        </div>
                                    </div>

                                    <div class="mt-8 bg-blue-50 rounded-lg p-6 border border-blue-200">
                                        <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                            <i class="fas fa-info-circle text-blue-600 mr-2"></i>
                                            Complete Profile
                                        </h3>
                                        <div class="space-y-3">
                                            <div class="flex items-center justify-between">
                                                <span class="text-sm text-gray-700">Full Name</span>
                                                <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($admin['fullname']); ?></span>
                                            </div>
                                            <div class="flex items-center justify-between">
                                                <span class="text-sm text-gray-700">Email Address</span>
                                                <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($admin['email']); ?></span>
                                            </div>
                                            <div class="flex items-center justify-between">
                                                <span class="text-sm text-gray-700">Account Type</span>
                                                <span class="text-sm font-medium text-gray-900"><?php echo ucfirst($admin['role']); ?> Account</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Sidebar toggle functionality
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const toggleBtn = document.getElementById('toggleSidebar');

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        });

        // Tab switching functionality
        function switchTab(tabName) {
            // Hide all tab contents
            document.querySelectorAll('.tab-content').forEach(tab => {
                tab.classList.remove('active');
            });

            // Remove active class from all buttons
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active');
                btn.classList.add('hover:bg-gray-100');
            });

            // Show selected tab
            document.getElementById(tabName + '-tab').classList.add('active');

            // Add active class to clicked button
            event.target.closest('.tab-button').classList.add('active');
            event.target.closest('.tab-button').classList.remove('hover:bg-gray-100');
        }
    </script>
</body>
</html>