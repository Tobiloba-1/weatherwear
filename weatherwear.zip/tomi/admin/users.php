<?php
session_start();
include "../database/db.php";

// Check if the user is logged in as an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin' || !isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

// Handle deleting a user
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $delete_query = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "User deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Failed to delete user.";
    }
    header("Location: users.php");
    exit();
}

// Handle adding a user
if (isset($_POST['add_user'])) {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $add_query = "INSERT INTO users (fullname, email, role, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($add_query);
    $stmt->bind_param("ssss", $fullname, $email, $role, $password);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "User added successfully!";
    } else {
        $_SESSION['error_message'] = "Failed to add user. Email may already exist.";
    }
    header("Location: users.php");
    exit();
}

// Fetch all users from the database
$query = "SELECT id, fullname, email, role, created_at FROM users ORDER BY role DESC, created_at DESC";
$result = $conn->query($query);

// Get user counts
$admin_count_query = "SELECT COUNT(*) as count FROM users WHERE role = 'admin'";
$user_count_query = "SELECT COUNT(*) as count FROM users WHERE role = 'user'";
$admin_count = $conn->query($admin_count_query)->fetch_assoc()['count'];
$user_count = $conn->query($user_count_query)->fetch_assoc()['count'];
$total_users = $admin_count + $user_count;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 50;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s;
        }
        
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            animation: slideIn 0.3s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .alert {
            animation: slideDown 0.3s;
        }
        
        @keyframes slideDown {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .stat-card {
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .btn-hover {
            transition: all 0.3s;
        }

        .btn-hover:hover {
            transform: scale(1.05);
        }

        .table-row {
            transition: background-color 0.2s;
        }

        .table-row:hover {
            background-color: #f9fafb;
        }

        /* Sidebar collapse styles */
        aside {
            transition: margin-left 0.3s ease;
        }
        
        aside.collapsed {
            margin-left: -16rem;
        }
        
        main {
            transition: margin-left 0.3s ease;
        }
        
        main.expanded {
            margin-left: 0 !important;
        }
    </style>
</head>
<body class="bg-gray-50 font-sans antialiased">

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="w-64 bg-gradient-to-b from-blue-900 to-blue-800 text-white shadow-2xl fixed h-full z-40">
            <div class="p-6 border-b border-blue-700">
                <h2 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-shield-alt mr-3"></i>
                    Admin Panel
                </h2>
            </div>
            <nav class="mt-6">
                <ul class="space-y-2 px-4">
                    <li>
                        <a href="../admin/" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-chart-line w-6"></i>
                            <span class="ml-3">Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="users.php" class="flex items-center p-3 rounded-lg bg-blue-700 transition">
                            <i class="fas fa-users w-6"></i>
                            <span class="ml-3 font-semibold">Users</span>
                        </a>
                    </li>
                    <li>
                        <a href="feedback.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-comments w-6"></i>
                            <span class="ml-3">Feedback</span>
                        </a>
                    </li>
                    <li>
                        <a href="settings.php" class="flex items-center p-3 rounded-lg hover:bg-blue-700 transition">
                            <i class="fas fa-cog w-6"></i>
                            <span class="ml-3">Settings</span>
                        </a>
                    </li>
                    <li class="pt-4 mt-4 border-t border-blue-700">
                        <a href="../auth/logout.php" class="flex items-center p-3 rounded-lg hover:bg-red-600 transition">
                            <i class="fas fa-sign-out-alt w-6"></i>
                            <span class="ml-3">Log Out</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main id="mainContent" class="flex-1 overflow-y-auto ml-64">
            <!-- Header -->
            <header class="bg-white shadow-sm border-b border-gray-200">
                <div class="px-8 py-6">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <button id="toggleSidebar" class="mr-4 text-gray-600 hover:text-gray-900 focus:outline-none">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                            <div>
                                <h1 class="text-3xl font-bold text-gray-900">User Management</h1>
                                <p class="text-gray-600 mt-1">Manage all system users and their roles</p>
                            </div>
                        </div>
                        <button onclick="openModal('addUserModal')" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg shadow-md btn-hover flex items-center">
                            <i class="fas fa-plus mr-2"></i>
                            Add New User
                        </button>
                    </div>
                </div>
            </header>

            <div class="p-8">
                <!-- Alert Messages -->
                <?php if (isset($_SESSION['success_message'])): ?>
                    <div class="alert bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg shadow">
                        <div class="flex items-center">
                            <i class="fas fa-check-circle mr-3"></i>
                            <span><?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error_message'])): ?>
                    <div class="alert bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg shadow">
                        <div class="flex items-center">
                            <i class="fas fa-exclamation-circle mr-3"></i>
                            <span><?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?></span>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Statistics Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="stat-card bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-blue-100 text-sm font-medium uppercase">Total Users</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $total_users; ?></h3>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-users text-3xl"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-purple-100 text-sm font-medium uppercase">Administrators</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $admin_count; ?></h3>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-user-shield text-3xl"></i>
                            </div>
                        </div>
                    </div>

                    <div class="stat-card bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-green-100 text-sm font-medium uppercase">users</p>
                                <h3 class="text-4xl font-bold mt-2"><?php echo $user_count; ?></h3>
                            </div>
                            <div class="bg-white bg-opacity-20 rounded-full p-4">
                                <i class="fas fa-graduation-cap text-3xl"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Users Table -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200 bg-gray-50">
                        <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                            <i class="fas fa-list mr-2 text-blue-600"></i>
                            Users List
                        </h2>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-100">
                                <tr>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">#</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Email</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Joined</th>
                                    <th class="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                <?php
                                $no = 1;
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $role_badge = $row['role'] === 'admin' 
                                            ? '<span class="px-3 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800"><i class="fas fa-shield-alt mr-1"></i>Admin</span>'
                                            : '<span class="px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800"><i class="fas fa-user mr-1"></i>user</span>';
                                        
                                        echo "<tr class='table-row'>";
                                        echo "<td class='px-6 py-4 text-sm text-gray-900 font-medium'>$no</td>";
                                        echo "<td class='px-6 py-4'>";
                                        echo "  <div class='flex items-center'>";
                                        echo "    <div class='flex-shrink-0 h-10 w-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold'>";
                                        echo "      " . strtoupper(substr($row['fullname'], 0, 1)) . "";
                                        echo "    </div>";
                                        echo "    <div class='ml-4'>";
                                        echo "      <div class='text-sm font-medium text-gray-900'>{$row['fullname']}</div>";
                                        echo "    </div>";
                                        echo "  </div>";
                                        echo "</td>";
                                        echo "<td class='px-6 py-4 text-sm text-gray-700'>{$row['email']}</td>";
                                        echo "<td class='px-6 py-4'>$role_badge</td>";
                                        echo "<td class='px-6 py-4 text-sm text-gray-600'>" . date('M d, Y', strtotime($row['created_at'])) . "</td>";
                                        echo "<td class='px-6 py-4 text-sm'>";
                                        echo "  <button onclick=\"openModal('deleteUserModal{$row['id']}')\" class='text-red-600 hover:text-red-800 font-medium flex items-center'>";
                                        echo "    <i class='fas fa-trash-alt mr-1'></i> Delete";
                                        echo "  </button>";
                                        echo "</td>";
                                        echo "</tr>";

                                        // Delete confirmation modal
                                        echo "<div id='deleteUserModal{$row['id']}' class='modal'>";
                                        echo "  <div class='modal-content bg-white rounded-lg shadow-2xl max-w-md w-full mx-4'>";
                                        echo "    <div class='bg-red-600 text-white px-6 py-4 rounded-t-lg'>";
                                        echo "      <h3 class='text-xl font-bold flex items-center'>";
                                        echo "        <i class='fas fa-exclamation-triangle mr-2'></i> Confirm Deletion";
                                        echo "      </h3>";
                                        echo "    </div>";
                                        echo "    <div class='p-6'>";
                                        echo "      <p class='text-gray-700 mb-4'>Are you sure you want to delete <strong>{$row['fullname']}</strong>?</p>";
                                        echo "      <p class='text-sm text-gray-600'>This action cannot be undone.</p>";
                                        echo "    </div>";
                                        echo "    <div class='bg-gray-50 px-6 py-4 rounded-b-lg flex justify-end space-x-3'>";
                                        echo "      <button onclick=\"closeModal('deleteUserModal{$row['id']}')\" class='px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg font-medium transition'>Cancel</button>";
                                        echo "      <a href='users.php?delete_id={$row['id']}' class='px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition'>Delete</a>";
                                        echo "    </div>";
                                        echo "  </div>";
                                        echo "</div>";

                                        $no++;
                                    }
                                } else {
                                    echo "<tr><td colspan='6' class='px-6 py-8 text-center'>";
                                    echo "  <div class='text-gray-400'>";
                                    echo "    <i class='fas fa-users text-4xl mb-2'></i>";
                                    echo "    <p class='text-lg'>No users found</p>";
                                    echo "  </div>";
                                    echo "</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add User Modal -->
    <div id="addUserModal" class="modal">
        <div class="modal-content bg-white rounded-lg shadow-2xl max-w-md w-full mx-4">
            <div class="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                <h3 class="text-xl font-bold flex items-center">
                    <i class="fas fa-user-plus mr-2"></i> Add New User
                </h3>
            </div>
            <form action="users.php" method="POST" class="p-6">
                <div class="space-y-4">
                    <div>
                        <label for="fullname" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-user mr-1"></i> Full Name
                        </label>
                        <input type="text" id="fullname" name="fullname" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                    
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-envelope mr-1"></i> Email Address
                        </label>
                        <input type="email" id="email" name="email" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                    
                    <div>
                        <label for="role" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-user-tag mr-1"></i> Role
                        </label>
                        <select id="role" name="role" 
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                                required>
                            <option value="user">user</option>
                            <option value="admin">Administrator</option>
                        </select>
                    </div>
                    
                    <div>
                        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">
                            <i class="fas fa-lock mr-1"></i> Password
                        </label>
                        <input type="password" id="password" name="password" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required minlength="6">
                        <p class="text-xs text-gray-500 mt-1">Minimum 6 characters</p>
                    </div>
                </div>
                
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="closeModal('addUserModal')" 
                            class="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 rounded-lg font-medium transition">
                        Cancel
                    </button>
                    <button type="submit" name="add_user" 
                            class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition">
                        <i class="fas fa-plus mr-1"></i> Add User
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Sidebar toggle functionality
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');
        const toggleBtn = document.getElementById('toggleSidebar');

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('expanded');
        });

        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).classList.add('show');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('show');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('show');
            }
        }

        // Close modal on Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape') {
                document.querySelectorAll('.modal.show').forEach(modal => {
                    modal.classList.remove('show');
                });
            }
        });
    </script>
</body>
</html>