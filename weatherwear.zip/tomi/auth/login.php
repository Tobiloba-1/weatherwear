<?php
session_start();
include '../database/db.php'; // Include database connection
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Validate inputs
    if (empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Check if user exists
        $stmt = $conn->prepare("SELECT id, password, fullname, role, gender FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows == 0) {
            $error = "No user found with that email address.";
        } else {
            $stmt->bind_result($id, $hashed_password, $fullname, $role, $gender);
            $stmt->fetch();
        
            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['user'] = $fullname; // Add this
                $_SESSION['fullname'] = $fullname;
                $_SESSION['email'] = $email;
                $_SESSION['role'] = $role;
                $_SESSION['gender'] = $gender;
        
                if ($role === 'admin') {
                    header("Location: ../admin/");
                } elseif ($role === 'user') {
                    header("Location: ../dashboard/");
                } else {
                    header("Location: ../");
                }
                exit;
            } else {
                $error = "Incorrect password.";
            }
        }
        

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-blue-100 to-purple-200 min-h-screen flex items-center justify-center">

  <div class="w-full max-w-md p-8 bg-white rounded-2xl shadow-xl">
    <h2 class="text-3xl font-bold text-center text-blue-700 mb-6">Login</h2>

    <?php if ($error): ?>
      <div class="bg-red-100 text-red-800 p-3 rounded mb-4 text-center">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="space-y-5">
      <!-- Email -->
      <div>
        <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
        <input type="email" name="email" id="email" required placeholder="Enter Email Address"
               class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400" />
      </div>

      <!-- Password -->
      <div>
        <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
        <input type="password" name="password" id="password" required placeholder="Enter Password"
               class="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400" />
      </div>

      <!-- Submit Button -->
      <div>
        <button type="submit"
                class="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700 transition duration-200">
          Login
        </button>
      </div>
    </form>

    <p class="mt-4 text-sm text-center text-gray-600">Don't have an account? 
      <a href="register.php" class="text-blue-600 hover:underline">Sign up</a>
    </p>
  </div>

</body>
</html>
