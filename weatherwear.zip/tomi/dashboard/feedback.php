<?php
session_start();
require "../database/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location:../auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$successMessage = "";
$errorMessage = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['feedback'])) {
    $fullname = $_SESSION['fullname'] ?? $user;
    $email = $_SESSION['email'] ?? '';
    $feedback = trim($_POST['feedback']);
    
    if (empty($feedback)) {
        $errorMessage = "Please enter your feedback before submitting.";
    } else {
        $stmt = $conn->prepare("INSERT INTO feedback (fullname, email, feedback, submitted_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("sss", $fullname, $email, $feedback);
        
        if ($stmt->execute()) {
            $successMessage = "Thank you for your feedback! We appreciate your input.";
            $_POST['feedback'] = ''; // Clear the form
        } else {
            $errorMessage = "Something went wrong. Please try again later.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback - WeatherWear</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        .float-animation {
            animation: float 6s ease-in-out infinite;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        textarea:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .alert-message {
            animation: slideIn 0.5s ease-out;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="gradient-bg shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-6">
            <div class="flex items-center justify-between">
                <div class="text-white text-2xl font-bold flex items-center">
                    <i class="fas fa-cloud-sun-rain mr-3 text-3xl"></i>
                    <span>WeatherWear</span>
                </div>
                <a href="../dashboard/" class="bg-white text-purple-600 px-6 py-2 rounded-full font-semibold hover:bg-opacity-90 transition transform hover:scale-105 shadow-lg flex items-center">
                    <i class="fas fa-home mr-2"></i>
                    Dashboard
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="gradient-bg relative overflow-hidden py-16">
        <div class="absolute inset-0 opacity-10">
            <div class="absolute top-10 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl float-animation"></div>
            <div class="absolute bottom-10 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style="animation-delay: 2s"></div>
        </div>
        
        <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
            <div class="inline-block mb-4 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
                <span class="text-white font-medium">
                    <i class="fas fa-comment-dots mr-2"></i>We Value Your Opinion
                </span>
            </div>
            <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4">
                Share Your Feedback
            </h1>
            <p class="text-xl text-white text-opacity-90 max-w-2xl mx-auto">
                Help us improve WeatherWear by sharing your thoughts, suggestions, and experiences
            </p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="py-12">
        <div class="max-w-4xl mx-auto px-4">
            <!-- Alert Messages -->
            <?php if (!empty($successMessage)): ?>
                <div class="alert-message mb-8">
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl shadow-xl overflow-hidden border-2 border-green-200">
                        <div class="bg-gradient-to-r from-green-500 to-emerald-600 px-8 py-4">
                            <h3 class="text-xl font-bold text-white flex items-center">
                                <i class="fas fa-check-circle mr-3"></i>
                                Success!
                            </h3>
                        </div>
                        <div class="p-6">
                            <p class="text-gray-700 text-lg"><?= htmlspecialchars($successMessage) ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($errorMessage)): ?>
                <div class="alert-message mb-8">
                    <div class="bg-red-50 rounded-2xl shadow-xl overflow-hidden border-2 border-red-200">
                        <div class="bg-gradient-to-r from-red-500 to-red-600 px-8 py-4">
                            <h3 class="text-xl font-bold text-white flex items-center">
                                <i class="fas fa-exclamation-circle mr-3"></i>
                                Error
                            </h3>
                        </div>
                        <div class="p-6">
                            <p class="text-red-700 text-lg font-semibold"><?= htmlspecialchars($errorMessage) ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Feedback Form Card -->
            <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in-up">
                <div class="bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-6">
                    <h2 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-pencil-alt mr-3"></i>
                        Tell Us What You Think
                    </h2>
                    <p class="text-white text-opacity-90 mt-2">Your feedback helps us create a better experience for everyone</p>
                </div>

                <form action="" method="post" class="p-8">
                    <!-- User Info Display -->
                    <div class="mb-6 bg-purple-50 border-l-4 border-purple-500 p-4 rounded-lg">
                        <div class="flex items-start">
                            <i class="fas fa-user-circle text-purple-600 text-3xl mr-4 mt-1"></i>
                            <div>
                                <p class="text-sm text-gray-600 font-medium">Submitting as:</p>
                                <p class="text-lg font-bold text-gray-800"><?= htmlspecialchars($_SESSION['fullname'] ?? $user) ?></p>
                                <?php if (isset($_SESSION['email'])): ?>
                                    <p class="text-sm text-gray-600 mt-1">
                                        <i class="fas fa-envelope mr-1"></i>
                                        <?= htmlspecialchars($_SESSION['email']) ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Feedback Textarea -->
                    <div class="mb-6">
                        <label class="block text-gray-700 font-semibold mb-3 flex items-center text-lg">
                            <i class="fas fa-message mr-2 text-purple-600"></i>
                            Your Feedback
                        </label>
                        <textarea 
                            name="feedback" 
                            rows="8"
                            class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl transition resize-none text-gray-700"
                            placeholder="Share your thoughts, suggestions, bugs, or any feedback about WeatherWear. We'd love to hear from you!"
                            required
                        ><?= isset($_POST['feedback']) ? htmlspecialchars($_POST['feedback']) : '' ?></textarea>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="fas fa-info-circle mr-1"></i>
                            Be as detailed as you'd like. Every piece of feedback is valuable to us!
                        </p>
                    </div>

                    <!-- Submit Button -->
                    <button 
                        type="submit" 
                        class="btn-primary w-full text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center"
                    >
                        <i class="fas fa-paper-plane mr-2"></i>
                        Submit Feedback
                    </button>
                </form>
            </div>

            <!-- Why Feedback Matters Card -->
            <div class="mt-8 bg-white rounded-2xl shadow-lg p-8 card-hover">
                <div class="flex items-start mb-6">
                    <div class="bg-gradient-to-br from-orange-500 to-red-500 rounded-full p-4 mr-4">
                        <i class="fas fa-heart text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">Why Your Feedback Matters</h3>
                        <p class="text-gray-600">Every suggestion helps us make WeatherWear better for you</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-lightbulb text-blue-700 text-2xl"></i>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">New Features</h4>
                        <p class="text-sm text-gray-600">Your suggestions inspire new features and improvements</p>
                    </div>
                    
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-purple-100 to-purple-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-bug text-purple-700 text-2xl"></i>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">Bug Fixes</h4>
                        <p class="text-sm text-gray-600">Report issues to help us maintain quality</p>
                    </div>
                    
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-green-100 to-green-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-rocket text-green-700 text-2xl"></i>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">Better UX</h4>
                        <p class="text-sm text-gray-600">Shape the user experience for everyone</p>
                    </div>
                </div>
            </div>

            <!-- Feedback Categories Card -->
            <div class="mt-8 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl shadow-lg p-8 border-2 border-indigo-200">
                <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-list-check mr-2 text-indigo-600"></i>
                    What Can You Share?
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 text-xl mr-3 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-gray-800">Feature Requests</h4>
                            <p class="text-sm text-gray-600">Tell us what features you'd love to see</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 text-xl mr-3 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-gray-800">Bug Reports</h4>
                            <p class="text-sm text-gray-600">Let us know if something isn't working</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 text-xl mr-3 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-gray-800">User Experience</h4>
                            <p class="text-sm text-gray-600">Share thoughts on design and usability</p>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle text-green-500 text-xl mr-3 mt-1"></i>
                        <div>
                            <h4 class="font-semibold text-gray-800">General Feedback</h4>
                            <p class="text-sm text-gray-600">Any other thoughts or suggestions</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <a href="recommendation.php" class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl shadow-lg p-6 border-2 border-purple-200 hover:shadow-xl transition card-hover">
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-purple-500 to-pink-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-tshirt text-white text-xl"></i>
                        </div>
                        <h3 class="font-bold text-gray-800 text-sm">Outfit Recommendations</h3>
                    </div>
                </a>
                
                <a href="forecast.php" class="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl shadow-lg p-6 border-2 border-blue-200 hover:shadow-xl transition card-hover">
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-cloud-sun text-white text-xl"></i>
                        </div>
                        <h3 class="font-bold text-gray-800 text-sm">Weather Forecast</h3>
                    </div>
                </a>

                <a href="suggestion.php" class="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl shadow-lg p-6 border-2 border-orange-200 hover:shadow-xl transition card-hover">
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-orange-500 to-red-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                            <i class="fas fa-camera text-white text-xl"></i>
                        </div>
                        <h3 class="font-bold text-gray-800 text-sm">AI Styling</h3>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 mt-16">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <i class="fas fa-cloud-sun-rain text-3xl text-purple-400 mr-3"></i>
                    <span class="text-xl font-bold">WeatherWear</span>
                </div>
                <p class="text-gray-400 text-sm">
                    © 2025 WeatherWear. All rights reserved.
                </p>
                <div class="flex space-x-4 mt-4 md:mt-0">
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-facebook"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>