<?php
session_start();
include "../database/db.php"; // Include the database connection

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture the feedback from the POST request
    $feedback = trim($_POST['feedback']);
    
    // Check if the user is logged in (i.e., session variables for fullname and email exist)
    if (isset($_SESSION['fullname']) && isset($_SESSION['email'])) {
        $fullname = $_SESSION['fullname'];  // Get the fullname from the session
        $email = $_SESSION['email'];        // Get the email from the session
        
        // Perform basic validation to check if feedback is not empty
        if (!empty($feedback)) {
            try {
                // Prepare the SQL statement
                $stmt = $conn->prepare("INSERT INTO feedback (fullname, email, feedback) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $fullname, $email, $feedback);

                // Execute the statement and check if insertion was successful
                if ($stmt->execute()) {
                    $successMessage = "Thank you for your feedback!";
                    // Redirect to the forecast page after feedback is submitted
                    echo "<script>
                            alert('$successMessage');
                            setTimeout(function() {
                                location.href = 'forecast.html';
                            }, 100);
                        </script>";
                } else {
                    $errorMessage = "Error submitting your feedback. Please try again later.";
                }

                // Close the statement
                $stmt->close();
            } catch (Exception $e) {
                $errorMessage = "An error occurred: " . $e->getMessage();
            }
        } else {
            $errorMessage = "Please enter your feedback.";
        }
    } else {
        $errorMessage = "You need to be logged in to submit feedback.";
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.0/dist/tailwind.min.css" rel="stylesheet">
</head>

<body>
    <div class="max-w-lg mx-auto mt-10">
        <h1 class="text-3xl font-semibold text-center">We value your feedback!</h1>

        <!-- Display Success or Error message -->
        
    </div>
</body>

</html>
