const API_KEY = 'e8266b7af617e809f02780fc875e27bf';
let isCelsius = true;
let currentCity = '';

function getWeather() {
  const city = document.getElementById('cityInput').value;
  const output = document.getElementById('output');
  const loader = document.getElementById('loader');

  if (!city) {
    output.innerHTML = `
      <div class="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded-xl shadow-lg">
        <div class="flex items-center">
          <i class="fas fa-exclamation-triangle text-yellow-500 text-3xl mr-4"></i>
          <p class="text-gray-700 font-semibold">Please enter a city name</p>
        </div>
      </div>
    `;
    return;
  }

  loader.classList.remove('hidden');
  output.innerHTML = '';

  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=${isCelsius ? 'metric' : 'imperial'}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      loader.classList.add('hidden');
      if (data.cod !== 200) {
        output.innerHTML = `
          <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
            <div class="flex items-center">
              <i class="fas fa-times-circle text-red-500 text-3xl mr-4"></i>
              <p class="text-gray-700 font-semibold">Error: ${data.message}</p>
            </div>
          </div>
        `;
        return;
      }
      displayWeather(data);
    })
    .catch(error => {
      loader.classList.add('hidden');
      output.innerHTML = `
        <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
          <div class="flex items-center">
            <i class="fas fa-exclamation-circle text-red-500 text-3xl mr-4"></i>
            <p class="text-gray-700 font-semibold">Something went wrong. Please try again.</p>
          </div>
        </div>
      `;
      console.error(error);
    });
}

function displayWeather(data) {
  const output = document.getElementById('output');
  const temp = data.main.temp;
  const recommendation = getClothingRecommendation(temp);
  const weatherIcon = data.weather[0].icon;
  const humidity = data.main.humidity;
  const windSpeed = data.wind.speed;
  const weatherCondition = data.weather[0].description;
  const currentDate = new Date().toLocaleString();

  output.innerHTML = `
    <div class="weather-card rounded-2xl shadow-2xl overflow-hidden border-2 border-blue-200 fade-in-up">
      <div class="bg-gradient-to-br from-blue-500 to-purple-600 px-8 py-6 text-white">
        <h3 class="text-3xl font-bold flex items-center">
          <i class="fas fa-map-marker-alt mr-3"></i>${data.name}, ${data.sys.country}
        </h3>
        <p class="text-white text-opacity-90 mt-2"><i class="far fa-clock mr-2"></i>${currentDate}</p>
      </div>
      
      <div class="p-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div class="text-center">
            <img src="https://openweathermap.org/img/wn/${weatherIcon}@4x.png" class="mx-auto w-32 h-32" alt="Weather icon">
            <div class="text-6xl font-extrabold text-gray-800 my-4">${temp}°${isCelsius ? 'C' : 'F'}</div>
            <p class="text-xl text-gray-600 capitalize font-medium"><i class="fas fa-cloud mr-2"></i>${weatherCondition}</p>
          </div>
          <div class="space-y-4">
            <div class="bg-blue-50 rounded-xl p-4 flex items-center">
              <i class="fas fa-tint text-blue-500 text-2xl mr-4"></i>
              <div>
                <p class="text-sm text-gray-600">Humidity</p>
                <p class="text-xl font-bold text-gray-800">${humidity}%</p>
              </div>
            </div>
            <div class="bg-cyan-50 rounded-xl p-4 flex items-center">
              <i class="fas fa-wind text-cyan-500 text-2xl mr-4"></i>
              <div>
                <p class="text-sm text-gray-600">Wind Speed</p>
                <p class="text-xl font-bold text-gray-800">${windSpeed} m/s</p>
              </div>
            </div>
            <div class="bg-orange-50 rounded-xl p-4 flex items-center">
              <i class="fas fa-temperature-high text-orange-500 text-2xl mr-4"></i>
              <div>
                <p class="text-sm text-gray-600">Feels Like</p>
                <p class="text-xl font-bold text-gray-800">${data.main.feels_like}°${isCelsius ? 'C' : 'F'}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="mt-8 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border-2 border-purple-200">
          <h4 class="text-xl font-bold text-gray-800 mb-3 flex items-center">
            <i class="fas fa-tshirt text-purple-600 mr-2"></i>Clothing Recommendation
          </h4>
          <p class="text-gray-700 text-lg leading-relaxed">${recommendation}</p>
        </div>
      </div>
    </div>
  `;
}

function getForecast(city) {
  const forecastOutput = document.getElementById('forecast');
  const loader = document.getElementById('loader');

  if (!city) {
    forecastOutput.innerHTML = `
      <div class="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded-xl shadow-lg">
        <div class="flex items-center">
          <i class="fas fa-exclamation-triangle text-yellow-500 text-3xl mr-4"></i>
          <p class="text-gray-700 font-semibold">Please enter a city or use your location first</p>
        </div>
      </div>
    `;
    return;
  }

  loader.classList.remove('hidden');
  forecastOutput.innerHTML = '';

  const url = `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}&units=${isCelsius ? 'metric' : 'imperial'}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      loader.classList.add('hidden');

      if (data.cod !== '200') {
        forecastOutput.innerHTML = `
          <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
            <div class="flex items-center">
              <i class="fas fa-times-circle text-red-500 text-3xl mr-4"></i>
              <p class="text-gray-700 font-semibold">Error: ${data.message}</p>
            </div>
          </div>
        `;
        return;
      }

      let forecastHTML = `
        <div class="bg-white rounded-2xl shadow-2xl overflow-hidden border-2 border-orange-200">
          <div class="bg-gradient-to-r from-orange-600 to-red-600 px-8 py-6">
            <h3 class="text-3xl font-bold text-white flex items-center">
              <i class="fas fa-calendar-alt mr-3"></i>5-Day Weather Forecast
            </h3>
            <p class="text-white text-opacity-90 mt-2">Plan your outfits for the week ahead</p>
          </div>
          <div class="p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
      `;

      let dayCount = 0;

      for (let i = 0; i < data.list.length; i++) {
        if (i % 8 === 0 && dayCount < 5) {
          const temp = data.list[i].main.temp;
          const weatherIcon = data.list[i].weather[0].icon;
          const date = new Date(data.list[i].dt_txt).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
          const recommendation = getClothingRecommendation(temp);

          forecastHTML += `
            <div class="forecast-card bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl p-6 border-2 border-blue-200 hover:shadow-xl transition">
              <p class="text-gray-800 font-bold text-lg mb-3">${date}</p>
              <img src="https://openweathermap.org/img/wn/${weatherIcon}@2x.png" class="mx-auto w-20 h-20" alt="Weather icon">
              <p class="text-3xl font-bold text-gray-800 text-center my-3">${temp}°${isCelsius ? 'C' : 'F'}</p>
              <div class="bg-white rounded-lg p-3 mt-4">
                <p class="text-sm text-gray-700">${recommendation}</p>
              </div>
            </div>
          `;
          dayCount++;
        }
      }

      forecastHTML += `</div></div>`;
      forecastOutput.innerHTML = forecastHTML;
    })
    .catch(error => {
      loader.classList.add('hidden');
      forecastOutput.innerHTML = `
        <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
          <div class="flex items-center">
            <i class="fas fa-exclamation-circle text-red-500 text-3xl mr-4"></i>
            <p class="text-gray-700 font-semibold">Something went wrong with forecast data.</p>
          </div>
        </div>
      `;
      console.error(error);
    });
}

function viewForecast() {
  if (currentCity) {
    getForecast(currentCity);
  } else {
    const city = document.getElementById('cityInput').value;
    if (city) {
      getForecast(city);
    } else {
      document.getElementById('forecast').innerHTML = `
        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded-xl shadow-lg">
          <div class="flex items-center">
            <i class="fas fa-exclamation-triangle text-yellow-500 text-3xl mr-4"></i>
            <p class="text-gray-700 font-semibold">Please enter a city or use your location first</p>
          </div>
        </div>
      `;
    }
  }
}

function getClothingRecommendation(temp) {
    if (temp >= 55) return "Scorching 🥵 – Avoid outdoor activity. Wear very light clothing, carry water, and stay in shade.";
    if (temp >= 50) return "Blistering 🔥 – Breathable, loose clothing. Hydration is crucial.";
    if (temp >= 45) return "Extreme heat 🌡️ – Sleeveless tops, shorts, hat, sunglasses, and SPF.";
    if (temp >= 40) return "Very hot 🌞 – Tank tops, summer hats, and light-colored clothes.";
    if (temp >= 35) return "Hot ☀️ – Light T-shirt, shorts, stay hydrated and cool.";
    if (temp >= 32) return "Warm and humid 💧 – Short sleeves, airy pants or skirts.";
    if (temp >= 30) return "Warm 🏖️ – Light shirt, shorts or dresses, sunglasses.";
    if (temp >= 28) return "Pleasantly warm 🌤️ – T-shirt and casual wear.";
    if (temp >= 26) return "Mild summer 🌼 – Tee, light pants or skirt.";
    if (temp >= 24) return "Slightly warm 🍃 – Short sleeve shirt, maybe light jacket at night.";
    if (temp >= 22) return "Neutral 👕 – Short or long sleeves depending on breeze.";
    if (temp >= 20) return "Mild 👔 – Jeans and a T-shirt, optional thin jacket.";
    if (temp >= 18) return "Slightly cool ☁️ – Long sleeve shirt or cardigan.";
    if (temp >= 16) return "Chilly breeze 🌬️ – Hoodie or light sweater recommended.";
    if (temp >= 14) return "Cool autumn 🍂 – Sweater, jeans, maybe scarf.";
    if (temp >= 12) return "Cold-ish 🍁 – Light coat or jacket with layered shirt.";
    if (temp >= 10) return "Chilly 🧥 – Hoodie or coat, closed shoes.";
    if (temp >= 8)  return "Cold 🧣 – Coat, scarf, and warm socks.";
    if (temp >= 5)  return "Cold weather ❄️ – Jacket, gloves, warm hat.";
    if (temp >= 2)  return "Very cold 🧊 – Puffer coat, wool hat, gloves.";
    if (temp >= 0)  return "Freezing 🌨️ – Full winter gear needed.";
    if (temp >= -3) return "Below freezing ❄️ – Insulated coat, gloves, boots.";
    if (temp >= -7) return "Severe cold 🥶 – Thermal layers, windproof outerwear.";
    if (temp >= -10) return "Extreme cold 🚨 – Full gear: thermals, thick coat, scarf, gloves, boots.";
    if (temp >= -15) return "Brutal cold 💀 – Face mask, parka, inner insulation.";
    if (temp >= -20) return "Life-threatening cold 🆘 – Avoid going out. Use thermal layers, wool, down-filled jackets.";
    return "Arctic conditions 🌪️ – Emergency gear required. Do not go outside unless absolutely necessary.";
    }

function saveSettings() {
  const unit = document.getElementById('tempUnit').value;
  localStorage.setItem('unitPreference', unit);
  isCelsius = (unit === 'metric');
}

function getLocation() {
  const locationOutput = document.getElementById('locationOutput');
  
  if (navigator.geolocation) {
    locationOutput.innerHTML = '<p class="text-purple-600"><i class="fas fa-spinner fa-spin mr-2"></i>Getting your location...</p>';
    navigator.geolocation.getCurrentPosition(
      function(position) {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        getWeatherByCoordinates(lat, lon);
        reverseGeocode(lat, lon);
      },
      function(error) {
        locationOutput.innerHTML = '<p class="text-red-600"><i class="fas fa-times-circle mr-2"></i>Error: ' + error.message + '</p>';
      }
    );
  } else {
    locationOutput.innerHTML = '<p class="text-red-600"><i class="fas fa-times-circle mr-2"></i>Geolocation not supported</p>';
  }
}

function getWeatherByCoordinates(lat, lon) {
  const output = document.getElementById('output');
  const loader = document.getElementById('loader');

  loader.classList.remove('hidden');

  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=${isCelsius ? 'metric' : 'imperial'}`;

  fetch(url)
    .then(response => response.json())
    .then(data => {
      loader.classList.add('hidden');
      if (data.cod !== 200) {
        output.innerHTML = `
          <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
            <div class="flex items-center">
              <i class="fas fa-times-circle text-red-500 text-3xl mr-4"></i>
              <p class="text-gray-700 font-semibold">Error: ${data.message}</p>
            </div>
          </div>
        `;
        return;
      }
      displayWeather(data);
    })
    .catch(error => {
      loader.classList.add('hidden');
      output.innerHTML = `
        <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-xl shadow-lg">
          <div class="flex items-center">
            <i class="fas fa-exclamation-circle text-red-500 text-3xl mr-4"></i>
            <p class="text-gray-700 font-semibold">Something went wrong.</p>
          </div>
        </div>
      `;
      console.error(error);
    });
}

function reverseGeocode(lat, lon) {
  const locationOutput = document.getElementById('locationOutput');
  const geoUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${API_KEY}`;

  fetch(geoUrl)
    .then(response => response.json())
    .then(data => {
      currentCity = data.name;
      locationOutput.innerHTML = `<p class="text-green-600 font-semibold"><i class="fas fa-check-circle mr-2"></i>Your location: ${currentCity}</p>`;
    })
    .catch(error => {
      locationOutput.innerHTML = '<p class="text-red-600"><i class="fas fa-times-circle mr-2"></i>Unable to determine location</p>';
      console.error(error);
    });
}

window.onload = () => {
  const savedUnit = localStorage.getItem('unitPreference');
  if (savedUnit) {
    document.getElementById('tempUnit').value = savedUnit;
    isCelsius = (savedUnit === 'metric');
  }
};