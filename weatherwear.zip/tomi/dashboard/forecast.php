<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Weather Forecast - WeatherWear</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }
    .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    .card-hover { transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); }
    .card-hover:hover { transform: translateY(-4px); box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15); }
    @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
    .fade-in-up { animation: fadeInUp 0.8s ease-out; }
    @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-20px); } }
    .float-animation { animation: float 6s ease-in-out infinite; }
    .weather-card { backdrop-filter: blur(10px); background: rgba(255, 255, 255, 0.95); }
    .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); transition: all 0.3s ease; }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4); }
    @keyframes slideIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    .forecast-card { animation: slideIn 0.5s ease-out; }
  </style>
</head>
<body class="bg-gray-50">
  <!-- Header -->
  <header class="gradient-bg shadow-lg">
    <div class="max-w-7xl mx-auto px-4 py-6">
      <div class="flex items-center justify-between">
        <div class="text-white text-2xl font-bold flex items-center">
          <i class="fas fa-cloud-sun-rain mr-3 text-3xl"></i>
          <span>WeatherWear</span>
        </div>
        <a href="../dashboard/" class="bg-white text-purple-600 px-6 py-2 rounded-full font-semibold hover:bg-opacity-90 transition transform hover:scale-105 shadow-lg flex items-center">
          <i class="fas fa-home mr-2"></i> Dashboard
        </a>
      </div>
    </div>
  </header>

  <!-- Hero Section -->
  <section class="gradient-bg relative overflow-hidden py-16">
    <div class="absolute inset-0 opacity-10">
      <div class="absolute top-10 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl float-animation"></div>
      <div class="absolute bottom-10 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style="animation-delay: 2s"></div>
    </div>
    <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
      <div class="inline-block mb-4 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
        <span class="text-white font-medium"><i class="fas fa-cloud-sun mr-2"></i>Real-Time Weather Information</span>
      </div>
      <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4">Weather Forecast & Clothing Guide</h1>
      <p class="text-xl text-white text-opacity-90 max-w-2xl mx-auto">Get accurate weather information and smart outfit recommendations for any location</p>
    </div>
  </section>

  <!-- Main Content -->
  <section class="py-12">
    <div class="max-w-6xl mx-auto px-4">
      <!-- Search Card -->
      <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in-up mb-8">
        <div class="bg-gradient-to-r from-blue-600 to-cyan-600 px-8 py-6">
          <h2 class="text-2xl font-bold text-white flex items-center"><i class="fas fa-search-location mr-3"></i>Find Your Weather</h2>
          <p class="text-white text-opacity-90 mt-2">Enter a city or use your current location</p>
        </div>
        <div class="p-8">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="space-y-4">
              <label class="block text-gray-700 font-semibold mb-2"><i class="fas fa-city mr-2 text-blue-600"></i>Search by City</label>
              <input type="text" id="cityInput" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition" placeholder="e.g., Lagos, London, New York"/>
              <button onclick="getWeather()" class="w-full btn-primary text-white px-6 py-3 rounded-xl font-semibold shadow-lg flex items-center justify-center">
                <i class="fas fa-cloud-sun mr-2"></i>Check Weather
              </button>
            </div>
            <div class="space-y-4">
              <label class="block text-gray-700 font-semibold mb-2"><i class="fas fa-map-marker-alt mr-2 text-blue-600"></i>Use Current Location</label>
              <div class="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 border-2 border-blue-200 h-full flex flex-col justify-center">
                <p class="text-gray-600 mb-4 text-center"><i class="fas fa-compass text-3xl text-blue-500 mb-2"></i><br>Get instant weather for your location</p>
                <button onclick="getLocation()" class="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition transform hover:scale-105 flex items-center justify-center">
                  <i class="fas fa-location-arrow mr-2"></i>Use My Location
                </button>
              </div>
            </div>
          </div>
          <div class="mt-6 flex items-center justify-center space-x-4 bg-gray-50 rounded-xl p-4">
            <i class="fas fa-thermometer-half text-purple-600 text-xl"></i>
            <label class="text-gray-700 font-semibold">Temperature Unit:</label>
            <select id="tempUnit" onchange="saveSettings()" class="px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-purple-500 focus:outline-none cursor-pointer font-medium">
              <option value="metric">Celsius (°C)</option>
              <option value="imperial">Fahrenheit (°F)</option>
            </select>
          </div>
          <div id="locationOutput" class="mt-4 text-center text-gray-600 font-medium"></div>
        </div>
      </div>

      <div id="loader" class="hidden text-center py-8">
        <div class="inline-block">
          <i class="fas fa-spinner fa-spin text-5xl text-purple-600"></i>
          <p class="mt-4 text-gray-600 font-semibold">Loading weather data...</p>
        </div>
      </div>

      <div id="output"></div>

      <div class="text-center my-8">
        <button onclick="viewForecast()" class="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition transform hover:scale-105 flex items-center justify-center mx-auto">
          <i class="fas fa-calendar-week mr-2"></i>View 5-Day Forecast
        </button>
      </div>

      <div id="forecast"></div>

      <!-- Feedback -->
      <div class="mt-12 bg-white rounded-2xl shadow-xl overflow-hidden">
        <div class="bg-gradient-to-r from-green-600 to-teal-600 px-8 py-6">
          <h2 class="text-2xl font-bold text-white flex items-center"><i class="fas fa-comment-dots mr-3"></i>Share Your Feedback</h2>
          <p class="text-white text-opacity-90 mt-2">Help us improve your experience</p>
        </div>
        <form action="feedbackk.php" method="post" class="p-8">
          <textarea id="feedback" name="feedback" rows="4" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-green-500 focus:outline-none transition resize-none" placeholder="Tell us what you think about WeatherWear..." required></textarea>
          <button type="submit" class="mt-4 bg-gradient-to-r from-green-500 to-teal-600 text-white px-8 py-3 rounded-xl font-semibold hover:shadow-lg transition transform hover:scale-105 flex items-center">
            <i class="fas fa-paper-plane mr-2"></i>Submit Feedback
          </button>
        </form>
      </div>

      <!-- Quick Link -->
      <div class="mt-8 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl shadow-lg p-8 border-2 border-purple-200">
        <div class="flex items-center justify-between flex-wrap gap-4">
          <div class="flex items-center">
            <div class="bg-gradient-to-br from-purple-500 to-pink-500 rounded-full p-4 mr-4">
              <i class="fas fa-tshirt text-white text-2xl"></i>
            </div>
            <div>
              <h3 class="text-xl font-bold text-gray-800">Want Detailed Outfit Recommendations?</h3>
              <p class="text-gray-600 mt-1">Get AI-powered clothing suggestions based on your style preferences</p>
            </div>
          </div>
          <a href="recommendation.php" class="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg transition transform hover:scale-105 flex items-center whitespace-nowrap">
            Try Now <i class="fas fa-arrow-right ml-2"></i>
          </a>
        </div>
      </div>
    </div>
  </section>

  <footer class="bg-gray-900 text-white py-12 mt-16">
    <div class="max-w-7xl mx-auto px-4">
      <div class="flex flex-col md:flex-row justify-between items-center">
        <div class="flex items-center mb-4 md:mb-0">
          <i class="fas fa-cloud-sun-rain text-3xl text-purple-400 mr-3"></i>
          <span class="text-xl font-bold">WeatherWear</span>
        </div>
        <p class="text-gray-400 text-sm">© 2025 WeatherWear. All rights reserved.</p>
        <div class="flex space-x-4 mt-4 md:mt-0">
          <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition"><i class="fab fa-instagram"></i></a>
          <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition"><i class="fab fa-twitter"></i></a>
          <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition"><i class="fab fa-facebook"></i></a>
        </div>
      </div>
    </div>
  </footer>

  <script src="forecast.js"></script>
</body>
</html>