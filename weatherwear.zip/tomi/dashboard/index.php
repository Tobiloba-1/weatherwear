<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WeatherWear Dashboard</title>
  <script src="https://unpkg.com/react@18.2.0/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18.2.0/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone@7.25.6/babel.min.js"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    body {
      font-family: 'Inter', sans-serif;
    }
    
    .gradient-bg {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .card-hover {
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .card-hover:hover {
      transform: translateY(-8px);
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    }
    
    .feature-card {
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
      transition: all 0.3s ease;
    }
    
    .feature-card:hover {
      transform: scale(1.05);
    }
    
    @keyframes float {
      0%, 100% { transform: translateY(0px); }
      50% { transform: translateY(-20px); }
    }
    
    .float-animation {
      animation: float 6s ease-in-out infinite;
    }
    
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in-up {
      animation: fadeInUp 0.8s ease-out;
    }
    
    .nav-link {
      position: relative;
      transition: color 0.3s;
    }
    
    .nav-link::after {
      content: '';
      position: absolute;
      bottom: -4px;
      left: 0;
      width: 0;
      height: 2px;
      background: white;
      transition: width 0.3s;
    }
    
    .nav-link:hover::after {
      width: 100%;
    }
    
    .mobile-menu {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease-out;
    }
    
    .mobile-menu.open {
      max-height: 500px;
    }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState, useEffect } = React;

    class ErrorBoundary extends React.Component {
      state = { hasError: false };

      static getDerivedStateFromError(error) {
        return { hasError: true };
      }

      render() {
        if (this.state.hasError) {
          return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100">
              <div className="text-center">
                <i className="fas fa-exclamation-triangle text-red-500 text-6xl mb-4"></i>
                <h1 className="text-2xl font-bold text-gray-800 mb-2">Oops! Something went wrong</h1>
                <p className="text-gray-600">Please refresh the page or check the console for details.</p>
              </div>
            </div>
          );
        }
        return this.props.children;
      }
    }

    const Header = () => {
      const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
      const [scrolled, setScrolled] = useState(false);

      useEffect(() => {
        const handleScroll = () => {
          setScrolled(window.scrollY > 20);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
      }, []);

      return (
        <header className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-lg' : 'bg-transparent'}`}>
          <div className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className={`text-2xl font-bold flex items-center ${scrolled ? 'text-purple-600' : 'text-white'}`}>
                <i className="fas fa-cloud-sun-rain mr-3 text-3xl"></i>
                <span>WeatherWear</span>
              </div>
              
              <nav className="hidden md:flex space-x-8">
                <a href="#overview" className={`nav-link font-medium ${scrolled ? 'text-gray-800' : 'text-white'}`}>
                  Overview
                </a>
                <a href="#features" className={`nav-link font-medium ${scrolled ? 'text-gray-800' : 'text-white'}`}>
                  Features
                </a>
                <a href="#navigation" className={`nav-link font-medium ${scrolled ? 'text-gray-800' : 'text-white'}`}>
                  Navigation
                </a>
                <a href="#documents" className={`nav-link font-medium ${scrolled ? 'text-gray-800' : 'text-white'}`}>
                  Documents
                </a>
              </nav>
              
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className={`md:hidden focus:outline-none ${scrolled ? 'text-gray-800' : 'text-white'}`}
              >
                <i className={`fas ${mobileMenuOpen ? 'fa-times' : 'fa-bars'} text-2xl`}></i>
              </button>
            </div>
            
            <div className={`mobile-menu md:hidden ${mobileMenuOpen ? 'open' : ''}`}>
              <nav className="flex flex-col space-y-4 pt-4 pb-2">
                <a href="#overview" className="text-gray-800 hover:text-purple-600 font-medium">Overview</a>
                <a href="#features" className="text-gray-800 hover:text-purple-600 font-medium">Features</a>
                <a href="#navigation" className="text-gray-800 hover:text-purple-600 font-medium">Navigation</a>
                <a href="#documents" className="text-gray-800 hover:text-purple-600 font-medium">Documents</a>
              </nav>
            </div>
          </div>
        </header>
      );
    };

    const Hero = () => (
      <section id="overview" className="gradient-bg min-h-screen flex items-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl float-animation"></div>
          <div className="absolute top-40 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-20 left-1/2 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style={{animationDelay: '4s'}}></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 py-24 relative z-10">
          <div className="text-center fade-in-up">
            <div className="inline-block mb-6 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
              <span className="text-white font-medium">
                <i className="fas fa-star mr-2"></i>Smart Weather-Based Fashion
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight">
              Dress Perfect for<br />
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-200 to-pink-200">
                Every Weather
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-white text-opacity-90 max-w-3xl mx-auto mb-10 leading-relaxed">
              WeatherWear is your intelligent fashion companion that analyzes real-time weather conditions 
              and recommends the perfect outfit for any climate.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a
                href="#navigation"
                className="group bg-white text-purple-600 px-8 py-4 rounded-full font-semibold hover:bg-opacity-90 transition transform hover:scale-105 shadow-2xl flex items-center justify-center"
              >
                <span>Get Started</span>
                <i className="fas fa-arrow-right ml-2 group-hover:translate-x-2 transition-transform"></i>
              </a>
              <a
                href="#features"
                className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white hover:text-purple-600 transition flex items-center justify-center"
              >
                <i className="fas fa-play-circle mr-2"></i>
                <span>Learn More</span>
              </a>
            </div>
            
            <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">24/7</div>
                <div className="text-white text-opacity-80 text-sm">Weather Updates</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">1000+</div>
                <div className="text-white text-opacity-80 text-sm">Outfit Styles</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">50K+</div>
                <div className="text-white text-opacity-80 text-sm">Happy Users</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-white mb-2">100%</div>
                <div className="text-white text-opacity-80 text-sm">Accurate</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );

    const Features = () => {
      const features = [
        {
          icon: 'fa-cloud-sun',
          title: 'Real-Time Weather',
          description: 'Get accurate weather forecasts from anywhere in the world',
          gradient: 'from-blue-400 to-cyan-400'
        },
        {
          icon: 'fa-tshirt',
          title: 'Smart Recommendations',
          description: 'AI-powered outfit suggestions based on temperature and conditions',
          gradient: 'from-purple-400 to-pink-400'
        },
        {
          icon: 'fa-user-circle',
          title: 'Personal Preferences',
          description: 'Customize your style preferences and save favorite outfits',
          gradient: 'from-orange-400 to-red-400'
        },
        {
          icon: 'fa-mobile-alt',
          title: 'Mobile Friendly',
          description: 'Access your wardrobe assistant on any device, anywhere',
          gradient: 'from-green-400 to-teal-400'
        }
      ];

      return (
        <section id="features" className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-purple-100 rounded-full mb-4">
                <span className="text-purple-600 font-semibold">
                  <i className="fas fa-bolt mr-2"></i>Features
                </span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
                Everything You Need
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Powerful features designed to make your daily outfit decisions effortless
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div key={index} className="feature-card rounded-2xl p-8 text-center">
                  <div className={`w-16 h-16 mx-auto mb-6 rounded-full bg-gradient-to-br ${feature.gradient} flex items-center justify-center shadow-lg`}>
                    <i className={`fas ${feature.icon} text-3xl text-white`}></i>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      );
    };

    const Navigation = () => {
      const pages = [
        {
          title: 'Weather Forecast',
          description: 'Enter your location to get detailed weather information',
          icon: 'fa-cloud-sun-rain',
          link: 'forecast.php',
          color: 'from-blue-500 to-cyan-500'
        },
        {
          title: 'Outfit Recommendations',
          description: 'Get personalized clothing suggestions for today\'s weather',
          icon: 'fa-tshirt',
          link: 'recommendation.php',
          color: 'from-purple-500 to-pink-500'
        },
        {
          title: 'User Profile',
          description: 'Manage your preferences and saved outfits',
          icon: 'fa-user-circle',
          link: '/user-profile',
          color: 'from-orange-500 to-red-500'
        },
        {
          title: 'Feedback',
          description: 'Help us grow better by sharing your feedback',
          icon: 'fa-envelope',
          link: 'feedback.php',
          color: 'from-green-500 to-teal-500'
        },
        {
          title: 'Support',
          description: 'Get help or contact our support team',
          icon: 'fa-headset',
          link: '/support',
          color: 'from-indigo-500 to-purple-500'
        },
        {
          title: 'Dashboard Home',
          description: 'Return to the main dashboard',
          icon: 'fa-home',
          link: '#',
          color: 'from-gray-500 to-gray-600'
        }
      ];

      return (
        <section id="navigation" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-blue-100 rounded-full mb-4">
                <span className="text-blue-600 font-semibold">
                  <i className="fas fa-compass mr-2"></i>Navigation
                </span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
                Explore WeatherWear
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Quick access to all features and functionalities
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pages.map((page, index) => (
                <a
                  key={index}
                  href={page.link}
                  className="card-hover bg-white rounded-2xl p-8 shadow-lg border border-gray-100 group"
                >
                  <div className={`w-16 h-16 mb-6 rounded-xl bg-gradient-to-br ${page.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform`}>
                    <i className={`fas ${page.icon} text-3xl text-white`}></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-3 group-hover:text-purple-600 transition">
                    {page.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4">{page.description}</p>
                  <div className="flex items-center text-purple-600 font-semibold">
                    <span>Explore</span>
                    <i className="fas fa-arrow-right ml-2 group-hover:translate-x-2 transition-transform"></i>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      );
    };

    const Documents = () => {
      const docs = [
        {
          title: 'User Guide',
          description: 'Complete guide to using WeatherWear effectively',
          icon: 'fa-book',
          link: '/docs/user-guide.pdf',
          color: 'text-blue-600'
        },
        {
          title: 'Technical Manual',
          description: 'System architecture and API documentation',
          icon: 'fa-code',
          link: '/docs/technical-manual.pdf',
          color: 'text-purple-600'
        },
        {
          title: 'FAQ',
          description: 'Answers to frequently asked questions',
          icon: 'fa-question-circle',
          link: '/docs/faq.pdf',
          color: 'text-green-600'
        },
        {
          title: 'Privacy Policy',
          description: 'How we protect and handle your data',
          icon: 'fa-shield-alt',
          link: '/docs/privacy-policy.pdf',
          color: 'text-orange-600'
        },
        {
          title: 'Terms of Service',
          description: 'Terms governing WeatherWear usage',
          icon: 'fa-file-contract',
          link: '/docs/terms-of-service.pdf',
          color: 'text-red-600'
        }
      ];

      return (
        <section id="documents" className="py-24 bg-gradient-to-b from-gray-50 to-white">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-16">
              <div className="inline-block px-4 py-2 bg-green-100 rounded-full mb-4">
                <span className="text-green-600 font-semibold">
                  <i className="fas fa-file-alt mr-2"></i>Documentation
                </span>
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
                Resources & Guides
              </h2>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Everything you need to know about WeatherWear
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {docs.map((doc, index) => (
                <a
                  key={index}
                  href={doc.link}
                  className="card-hover bg-white rounded-2xl p-8 shadow-lg border border-gray-100 group"
                >
                  <div className={`text-5xl mb-6 ${doc.color} group-hover:scale-110 transition-transform`}>
                    <i className={`fas ${doc.icon}`}></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-800 mb-3">{doc.title}</h3>
                  <p className="text-gray-600 leading-relaxed mb-4">{doc.description}</p>
                  <div className="flex items-center text-purple-600 font-semibold">
                    <span>Download PDF</span>
                    <i className="fas fa-download ml-2"></i>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      );
    };

    const Footer = () => (
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center mb-4">
                <i className="fas fa-cloud-sun-rain text-4xl text-purple-400 mr-3"></i>
                <span className="text-2xl font-bold">WeatherWear</span>
              </div>
              <p className="text-gray-400 leading-relaxed mb-6">
                Your intelligent fashion companion for every weather condition. 
                Making outfit decisions effortless, one forecast at a time.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                  <i className="fab fa-facebook"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-3">
                <li><a href="#overview" className="text-gray-400 hover:text-purple-400 transition">Overview</a></li>
                <li><a href="#features" className="text-gray-400 hover:text-purple-400 transition">Features</a></li>
                <li><a href="#navigation" className="text-gray-400 hover:text-purple-400 transition">Navigation</a></li>
                <li><a href="#documents" className="text-gray-400 hover:text-purple-400 transition">Documents</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <i className="fas fa-envelope text-purple-400 mr-3 mt-1"></i>
                  <a href="mailto:tobilobaowoeye96@gmail.com" className="text-gray-400 hover:text-purple-400 transition">
                    tobilobaowoeye96@gmail.com
                  </a>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-phone text-purple-400 mr-3 mt-1"></i>
                  <span className="text-gray-400">+123 456 789</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-map-marker-alt text-purple-400 mr-3 mt-1"></i>
                  <span className="text-gray-400">123 Fashion Street<br />Style City, FC 12345</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 WeatherWear. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm">
              <a href="/privacy" className="text-gray-400 hover:text-purple-400 transition">Privacy Policy</a>
              <a href="/terms" className="text-gray-400 hover:text-purple-400 transition">Terms of Service</a>
              <a href="/cookies" className="text-gray-400 hover:text-purple-400 transition">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    );

    const App = () => (
      <ErrorBoundary>
        <div className="overflow-x-hidden">
          <Header />
          <Hero />
          <Features />
          <Navigation />
          <Documents />
          <Footer />
        </div>
      </ErrorBoundary>
    );

    ReactDOM.render(<App />, document.getElementById('root'));
  </script>
</body>
</html>