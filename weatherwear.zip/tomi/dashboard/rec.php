<?php
$recommendation = '';
$imageUrl = '';
$avatarDescription = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $preferences = [
        'gender' => $_POST['gender'],
        'style' => $_POST['style'],
        'occasion' => $_POST['occasion'],
        'weather' => $_POST['weather'],
        'budget' => $_POST['budget'],
        'type' => $_POST['type'],
    ];

    $userPrompt = "Give clothing recommendations for a {$preferences['gender']} who prefers a {$preferences['style']} style, 
    and a body size of {$preferences['type']} body type, for a {$preferences['occasion']} occasion, 
    in {$preferences['weather']} weather, with a budget of {$preferences['budget']}.";

    $imagePrompt = "A 3D-rendered digital avatar of a {$preferences['gender']} with a {$preferences['type']} body type, styled like a video game character, wearing a {$preferences['style']} style outfit suitable for a {$preferences['occasion']} occasion in {$preferences['weather']} weather, with a {$preferences['budget']} budget. The avatar has a clean, cartoonish look with clear clothing details, posed in a neutral white background.";

    $descriptionPrompt = "Describe a 3D-rendered digital avatar of a {$preferences['gender']} with a {$preferences['type']} body type, styled like a video game character, wearing a {$preferences['style']} style outfit suitable for a {$preferences['occasion']} occasion in {$preferences['weather']} weather, with a {$preferences['budget']} budget. Provide a vivid description of the avatar’s appearance and clothing.";

    $apiKey = "";
    $chatEndpoint = "https://api.openai.com/v1/chat/completions";
    $imageEndpoint = "https://api.openai.com/v1/images/generations";

    function queryChatGPT($prompt, $apiKey, $endpoint) {
        $data = [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                ['role' => 'user', 'content' => $prompt],
            ],
            'temperature' => 0.8,
        ];

        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey",
        ]);

        $response = curl_exec($ch);
        if ($response === false) {
            echo "cURL Error: " . curl_error($ch);
        }
        curl_close($ch);

        $result = json_decode($response, true);
        if (!$result || !isset($result['choices'][0]['message']['content'])) {
            echo "API Error: " . json_encode($result);
        }
        return $result['choices'][0]['message']['content'] ?? null;
    }

    function queryDalle($prompt, $apiKey, $endpoint) {
        $data = [
            'model' => 'dall-e-3',
            'prompt' => $prompt,
            'n' => 1,
            'size' => '1024x1024',
            'quality' => 'standard',
        ];

        $ch = curl_init($endpoint);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer $apiKey",
        ]);

        $response = curl_exec($ch);
        if ($response === false) {
            echo "cURL Error: " . curl_error($ch);
        }
        curl_close($ch);

        $result = json_decode($response, true);
        if (!$result || !isset($result['data'][0]['url'])) {
            echo "DALL·E API Error: " . json_encode($result);
        }
        return $result['data'][0]['url'] ?? null;
    }

    // Get text recommendation
    $recommendation = queryChatGPT($userPrompt, $apiKey, $chatEndpoint);

    // Get avatar image
    $imageUrl = queryDalle($imagePrompt, $apiKey, $imageEndpoint);

    // Get avatar description as fallback
    $avatarDescription = queryChatGPT($descriptionPrompt, $apiKey, $chatEndpoint);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Clothing Recommendation</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.0.0/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
        <h1 class="text-2xl font-bold mb-4">Clothing Recommendation Form</h1>
        <form method="post" action="">
            <div class="mb-4">
                <label class="block mb-1">Gender</label>
                <select name="gender" class="w-full p-2 border rounded" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Style</label>
                <input type="text" name="style" class="w-full p-2 border rounded" placeholder="e.g. casual, corporate" required>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Occasion</label>
                <input type="text" name="occasion" class="w-full p-2 border rounded" placeholder="e.g. wedding, daily wear" required>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Weather</label>
                <input type="text" name="weather" class="w-full p-2 border rounded" placeholder="e.g. rainy, sunny" required>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Body Type</label>
                <input type="text" name="type" class="w-full p-2 border rounded" placeholder="e.g. slim, athletic" required>
            </div>
            <div class="mb-4">
                <label class="block mb-1">Budget</label>
                <input type="text" name="budget" class="w-full p-2 border rounded" placeholder="e.g. low, medium, high" required>
            </div>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Get Recommendation</button>
        </form>

        <?php if (!empty($recommendation)): ?>
            <div class="mt-6 bg-green-100 p-4 rounded border border-green-400">
                <h2 class="text-lg font-semibold mb-2">Your Clothing Recommendations:</h2>
                <p class="text-gray-800 whitespace-pre-line"><?php echo nl2br(htmlspecialchars($recommendation)); ?></p>
            </div>
        <?php endif; ?>

        <div class="mt-4">
            <!-- <h3 class="font-semibold mb-2">Avatar Visual Inspiration:</h3> -->
            <?php if (!empty($imageUrl)): ?>
                <img src="<?php echo htmlspecialchars($imageUrl); ?>" alt="Avatar with clothing" class="rounded shadow w-full">
                <p class="text-sm text-gray-600 mt-2">Generated by DALL·E 3. This is a 3D-rendered avatar with your selected clothing style.</p>
            <?php endif; ?>
            <?php if (!empty($avatarDescription)): ?>
                <p class="text-gray-800 whitespace-pre-line mt-2"><?php echo nl2br(htmlspecialchars($avatarDescription)); ?></p>
                <p class="text-sm text-gray-600 mt-2">This description complements the image. If the image isn't avatar-like, try adjusting your inputs or use this description to visualize the outfit.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>