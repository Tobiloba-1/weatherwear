<?php
session_start();
require "../database/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location:../auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$gender = $_SESSION['gender'];
$recommendation = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $preferences = [
        'gender'   => $_POST['gender'],
        'style'    => $_POST['style'],
        'occasion' => $_POST['occasion'],
        'type'     => $_POST['type'],
    ];

    // Prompt
    $userPrompt = "Give clothing recommendations for a {$preferences['gender']} who prefers a {$preferences['style']} style, 
    and a body size of {$preferences['type']} body type, for a {$preferences['occasion']} occasion. Make it more concise, and give multiple options";

    // CHATGPT API REQUEST
    $apiKey = ""; //Enter your api key here
    $endpoint = "https://api.openai.com/v1/chat/completions";

    $data = [
        'model' => 'gpt-3.5-turbo',
        'messages' => [
            ['role' => 'system', 'content' => 'You are a helpful fashion stylist.'],
            ['role' => 'user', 'content' => $userPrompt],
        ],
        'temperature' => 0.8,
        'max_tokens' => 500,
    ];

    $ch = curl_init($endpoint);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer $apiKey",
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);
    $recommendation = $result['choices'][0]['message']['content'] ?? "No recommendation received.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outfit Recommendations - WeatherWear</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-20px);
            }
        }

        .float-animation {
            animation: float 6s ease-in-out infinite;
        }

        .input-field {
            transition: all 0.3s ease;
        }

        .input-field:focus {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(102, 126, 234, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }

        .recommendation-card {
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
    </style>
</head>

<body class="bg-gray-50">
    <!-- Header -->
    <header class="gradient-bg shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-6">
            <div class="flex items-center justify-between">
                <div class="text-white text-2xl font-bold flex items-center">
                    <i class="fas fa-cloud-sun-rain mr-3 text-3xl"></i>
                    <span>WeatherWear</span>
                </div>
                <a href="../dashboard/" class="bg-white text-purple-600 px-6 py-2 rounded-full font-semibold hover:bg-opacity-90 transition transform hover:scale-105 shadow-lg flex items-center">
                    <i class="fas fa-home mr-2"></i>
                    Dashboard
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="gradient-bg relative overflow-hidden py-16">
        <div class="absolute inset-0 opacity-10">
            <div class="absolute top-10 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl float-animation"></div>
            <div class="absolute bottom-10 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style="animation-delay: 2s"></div>
        </div>

        <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
            <div class="inline-block mb-4 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
                <span class="text-white font-medium">
                    <i class="fas fa-tshirt mr-2"></i>AI-Powered Fashion Assistant
                </span>
            </div>
            <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4">
                Get Your Perfect Outfit
            </h1>
            <p class="text-xl text-white text-opacity-90 max-w-2xl mx-auto">
                Tell us your preferences and let AI create personalized clothing recommendations just for you
            </p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="py-12">
        <div class="max-w-4xl mx-auto px-4">
            <!-- Form Card -->
            <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in-up">
                <div class="bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-6">
                    <h2 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-magic mr-3"></i>
                        Your Style Preferences
                    </h2>
                    <p class="text-white text-opacity-90 mt-2">Fill in your details to receive tailored outfit suggestions</p>
                </div>

                <form method="post" action="" class="p-8 space-y-6">
                    <input type="hidden" name="gender" value="<?= htmlspecialchars($gender ?? '', ENT_QUOTES, 'UTF-8') ?>">

                    <!-- Gender Display (Read-only) -->
                    <div class="bg-purple-50 border-l-4 border-purple-500 p-4 rounded-lg">
                        <div class="flex items-center">
                            <i class="fas fa-user text-purple-600 text-xl mr-3"></i>
                            <div>
                                <p class="text-sm text-gray-600 font-medium">Gender</p>
                                <p class="text-lg font-semibold text-gray-800"><?= htmlspecialchars(ucfirst($gender ?? ''), ENT_QUOTES, 'UTF-8') ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Style Input -->
                    <div>
                        <label class="block text-gray-700 font-semibold mb-2 flex items-center">
                            <i class="fas fa-palette mr-2 text-purple-600"></i>
                            What's your preferred style?
                        </label>
                        <input
                            type="text"
                            name="style"
                            class="input-field w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                            placeholder="e.g., casual, corporate, streetwear, elegant"
                            required>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="fas fa-info-circle mr-1"></i>
                            Examples: casual, formal, sporty, bohemian, minimalist
                        </p>
                    </div>

                    <!-- Occasion Input -->
                    <div>
                        <label class="block text-gray-700 font-semibold mb-2 flex items-center">
                            <i class="fas fa-calendar-star mr-2 text-purple-600"></i>
                            What's the occasion?
                        </label>
                        <input
                            type="text"
                            name="occasion"
                            class="input-field w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                            placeholder="e.g., wedding, daily wear, job interview, date night"
                            required>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="fas fa-info-circle mr-1"></i>
                            Examples: work meeting, party, gym, casual outing, formal event
                        </p>
                    </div>

                    <!-- Body Type Input -->
                    <div>
                        <label class="block text-gray-700 font-semibold mb-2 flex items-center">
                            <i class="fas fa-ruler mr-2 text-purple-600"></i>
                            What's your body type?
                        </label>
                        <input
                            type="text"
                            name="type"
                            class="input-field w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none"
                            placeholder="e.g., slim, athletic, plus-size, petite"
                            required>
                        <p class="text-sm text-gray-500 mt-2">
                            <i class="fas fa-info-circle mr-1"></i>
                            Examples: slim, athletic, curvy, plus-size, petite, tall
                        </p>
                    </div>

                    <!-- Submit Button -->
                    <div class="flex flex-col sm:flex-row gap-4 pt-4">
                        <button
                            type="submit"
                            class="btn-primary flex-1 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center">
                            <i class="fas fa-sparkles mr-2"></i>
                            Get My Recommendations
                        </button>
                        <a
                            href="suggestion.php"
                            class="flex-1 bg-gray-100 text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-200 transition flex items-center justify-center">
                            <i class="fas fa-lightbulb mr-2"></i>
                            Browse Ideas
                        </a>
                    </div>
                </form>
            </div>

            <!-- Recommendation Results -->
            <?php if (!empty($recommendation)): ?>
                <div class="mt-8 recommendation-card">
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl shadow-xl overflow-hidden border-2 border-green-200">
                        <div class="bg-gradient-to-r from-green-500 to-emerald-600 px-8 py-6">
                            <h2 class="text-2xl font-bold text-white flex items-center">
                                <i class="fas fa-check-circle mr-3"></i>
                                Your Personalized Recommendations
                            </h2>
                            <p class="text-white text-opacity-90 mt-2">Here are outfit suggestions tailored just for you</p>
                        </div>

                        <div class="p-8">
                            <div class="bg-white rounded-xl p-6 shadow-md">
                                <div class="prose max-w-none text-gray-800 leading-relaxed whitespace-pre-line">
                                    <?= nl2br(htmlspecialchars($recommendation)) ?>
                                </div>
                            </div>

                            <div class="mt-6 flex flex-wrap gap-4">
                                <button
                                    onclick="window.print()"
                                    class="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition flex items-center">
                                    <i class="fas fa-print mr-2"></i>
                                    Print Recommendations
                                </button>
                                <button
                                    onclick="location.reload()"
                                    class="bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 transition flex items-center">
                                    <i class="fas fa-redo mr-2"></i>
                                    Get New Suggestions
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Quick Tips Card -->
            <div class="mt-8 bg-white rounded-2xl shadow-lg p-8 card-hover">
                <div class="flex items-start">
                    <div class="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full p-4 mr-4">
                        <i class="fas fa-lightbulb text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold text-gray-800 mb-3">Pro Tips for Better Recommendations</h3>
                        <ul class="space-y-2 text-gray-600">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mr-2 mt-1"></i>
                                <span>Be specific about your style preferences (e.g., "modern casual" vs just "casual")</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mr-2 mt-1"></i>
                                <span>Mention any colors or patterns you prefer</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mr-2 mt-1"></i>
                                <span>Consider the weather and season for your occasion</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mr-2 mt-1"></i>
                                <span>Try different combinations to discover new styles</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 mt-16">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <i class="fas fa-cloud-sun-rain text-3xl text-purple-400 mr-3"></i>
                    <span class="text-xl font-bold">WeatherWear</span>
                </div>
                <p class="text-gray-400 text-sm">
                    © 2025 WeatherWear. All rights reserved.
                </p>
                <div class="flex space-x-4 mt-4 md:mt-0">
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-facebook"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>