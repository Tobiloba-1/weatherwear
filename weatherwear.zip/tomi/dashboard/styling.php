<?php
session_start();
$response = '';
$error = '';
$image_url = null;

// Store your OpenAI API key securely
$api_key = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_query'])) {
    $user_query = trim($_POST['user_query']);

    // === Chat Completion (Styling Advice) ===
    $chat_payload = json_encode([
        "model" => "gpt-3.5-turbo",
        "messages" => [
            ["role" => "system", "content" => "You are a fashion stylist assistant."],
            ["role" => "user", "content" => $user_query]
        ],
        "temperature" => 0.7
    ]);

    $chat_curl = curl_init();
    curl_setopt_array($chat_curl, [
        CURLOPT_URL => 'https://api.openai.com/v1/chat/completions',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $chat_payload,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer $api_key",
            "Content-Type: application/json"
        ],
        // Disable SSL verification for local WAMP
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false
    ]);

    $chat_response = curl_exec($chat_curl);

    if ($chat_response === false) {
        $error = 'Chat API Error: ' . curl_error($chat_curl);
    } else {
        $data = json_decode($chat_response, true);
        if (isset($data['choices'][0]['message']['content'])) {
            $response = trim($data['choices'][0]['message']['content']);
        } else {
            $error = 'Chat API returned unexpected response: ' . json_encode($data['error'] ?? $data);
        }
    }
    curl_close($chat_curl);

    // === Image Generation ===
    if (empty($error) && !empty($response)) {
        // Shorten prompt to fit the API limit (max 1000 chars)
        $short_description = strtok($response, '.');
        $image_prompt = "Fashion outfit: " . substr($short_description, 0, 950);

        $image_payload = json_encode([
            "prompt" => $image_prompt,
            "n" => 1,
            "size" => "512x512"
        ]);

        $image_curl = curl_init();
        curl_setopt_array($image_curl, [
            CURLOPT_URL => 'https://api.openai.com/v1/images/generations',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $image_payload,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer $api_key",
                "Content-Type: application/json"
            ],
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ]);

        $image_response = curl_exec($image_curl);

        if ($image_response === false) {
            $error = 'Image generation error: ' . curl_error($image_curl);
        } else {
            $image_data = json_decode($image_response, true);
            if (isset($image_data['data'][0]['url'])) {
                $image_url = $image_data['data'][0]['url'];
            } else {
                $error = 'Image API returned unexpected response: ' . json_encode($image_data['error'] ?? $image_data);
            }
        }

        curl_close($image_curl);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Styling Assistant</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            padding-top: 50px;
        }
        .chatbox {
            width: 400px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .messages { margin-bottom: 20px; }
        .message { margin-bottom: 12px; }
        .user-message { font-weight: bold; }
        .bot-message { font-style: italic; }
        img { max-width: 100%; border-radius: 8px; margin-top: 10px; }
        input[type="text"] { width: calc(100% - 22px); padding: 10px; margin-top: 10px; border: 1px solid #ccc; border-radius: 6px; }
        button { width: 100%; padding: 10px; margin-top: 10px; background: #007BFF; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
<div class="chatbox">
    <div class="messages">
        <?php if (!empty($error)): ?>
            <div class="message bot-message">Bot: <?= nl2br(htmlspecialchars($error)) ?></div>
        <?php elseif (!empty($response)): ?>
            <div class="message user-message">You: <?= htmlspecialchars($user_query) ?></div>
            <div class="message bot-message">Bot: <?= nl2br(htmlspecialchars($response)) ?></div>
            <?php if (!empty($image_url)): ?>
                <div class="message"><img src="<?= htmlspecialchars($image_url) ?>" alt="Generated Outfit"></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <form method="POST" action="">
        <input type="text" name="user_query" placeholder="Ask for styling advice..." required>
        <button type="submit">Send</button>
    </form>
</div>
</body>
</html>
