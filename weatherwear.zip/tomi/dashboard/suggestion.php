<?php
// Start session if needed
session_start();

$responseText = "";
$errorMessage = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['outfit_image'])) {
    $allowedTypes = ['image/jpeg', 'image/png'];
    $maxFileSize = 5 * 1024 * 1024; // 5MB
    $uploadDir = 'Uploads/';

    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $file = $_FILES['outfit_image'];
    $imagePath = $uploadDir . basename($file['name']);

    // File validation
    if (!in_array($file['type'], $allowedTypes)) {
        $errorMessage = "Only JPEG and PNG images are allowed.";
    } elseif ($file['size'] > $maxFileSize) {
        $errorMessage = "File size exceeds 5MB limit.";
    } elseif ($file['error'] !== UPLOAD_ERR_OK) {
        $errorMessage = "File upload error: " . $file['error'];
    } elseif (file_exists($imagePath)) {
        $errorMessage = "File already exists. Please rename the file and try again.";
    } else {
        if (move_uploaded_file($file['tmp_name'], $imagePath)) {
            // Prepare prompt for OpenAI (text only)
            $prompt = "Provide styling suggestions for the outfit in the uploaded image: {$file['name']}. 
            Include complementary clothing, accessories, occasions, and styling tips in a concise list format.";

            $apiKey = getenv('') ?: ''; //Enter your api key here

            if (empty($apiKey)) {
                $errorMessage = "API key is missing. Configure OPENAI_API_KEY.";
            } else {
                $postData = [
                    "model" => "gpt-3.5-turbo",
                    "messages" => [
                        ["role" => "system", "content" => "You are a helpful fashion stylist."],
                        ["role" => "user", "content" => $prompt]
                    ],
                    "temperature" => 0.7,
                    "max_tokens" => 500
                ];

                $ch = curl_init("https://api.openai.com/v1/chat/completions");
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST => true,
                    CURLOPT_POSTFIELDS => json_encode($postData),
                    CURLOPT_HTTPHEADER => [
                        "Content-Type: application/json",
                        "Authorization: Bearer $apiKey"
                    ],
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false
                ]);

                $result = curl_exec($ch);
                if ($result === false) {
                    $errorMessage = "cURL error: " . curl_error($ch);
                } else {
                    $data = json_decode($result, true);
                    if (isset($data['choices'][0]['message']['content'])) {
                        $responseText = trim($data['choices'][0]['message']['content']);
                    } else {
                        $errorMessage = "Unexpected API response: " . json_encode($data);
                    }
                }
                curl_close($ch);
            }

            // Delete uploaded file after processing
            unlink($imagePath);
        } else {
            $errorMessage = "Failed to move uploaded file.";
        }
    }
}

// Function to format API response into HTML
function formatResponse($text) {
    $output = '';
    $lines = preg_split("/\r\n|\n|\r/", trim($text));

    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;

        // Bold labels like "Footwear: Description"
        $line = preg_replace('/^([A-Za-z\s]+):\s*(.+)/', '<span class="font-semibold text-purple-700">$1:</span> $2', $line);

        // List items
        if (preg_match('/^[-*]\s*(.+)/', $line, $matches)) {
            $output .= '<li class="mb-2 text-gray-700 leading-relaxed">' . $matches[1] . '</li>';
        } else {
            $output .= '<p class="mt-3 text-gray-700 leading-relaxed">' . $line . '</p>';
        }
    }

    // Wrap in <ul> if there are list items
    if (strpos($output, '<li>') !== false) {
        $output = '<ul class="list-disc pl-5 space-y-2">' . $output . '</ul>';
    }

    return $output;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Outfit Styling - WeatherWear</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .card-hover:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .fade-in-up {
            animation: fadeInUp 0.8s ease-out;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        .float-animation {
            animation: float 6s ease-in-out infinite;
        }
        
        .upload-area {
            border: 3px dashed #cbd5e0;
            transition: all 0.3s ease;
        }
        
        .upload-area:hover {
            border-color: #667eea;
            background-color: #f7fafc;
        }
        
        .upload-area.dragover {
            border-color: #667eea;
            background-color: #edf2f7;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .result-card {
            animation: slideIn 0.5s ease-out;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header -->
    <header class="gradient-bg shadow-lg">
        <div class="max-w-7xl mx-auto px-4 py-6">
            <div class="flex items-center justify-between">
                <div class="text-white text-2xl font-bold flex items-center">
                    <i class="fas fa-cloud-sun-rain mr-3 text-3xl"></i>
                    <span>WeatherWear</span>
                </div>
                <a href="../dashboard/" class="bg-white text-purple-600 px-6 py-2 rounded-full font-semibold hover:bg-opacity-90 transition transform hover:scale-105 shadow-lg flex items-center">
                    <i class="fas fa-home mr-2"></i>
                    Dashboard
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="gradient-bg relative overflow-hidden py-16">
        <div class="absolute inset-0 opacity-10">
            <div class="absolute top-10 left-20 w-72 h-72 bg-white rounded-full mix-blend-multiply filter blur-xl float-animation"></div>
            <div class="absolute bottom-10 right-20 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl float-animation" style="animation-delay: 2s"></div>
        </div>
        
        <div class="max-w-4xl mx-auto px-4 text-center relative z-10">
            <div class="inline-block mb-4 px-4 py-2 bg-white bg-opacity-20 rounded-full backdrop-blur-sm">
                <span class="text-white font-medium">
                    <i class="fas fa-camera mr-2"></i>AI-Powered Styling Assistant
                </span>
            </div>
            <h1 class="text-4xl md:text-5xl font-extrabold text-white mb-4">
                Upload Your Outfit for AI Suggestions
            </h1>
            <p class="text-xl text-white text-opacity-90 max-w-2xl mx-auto">
                Get personalized styling tips, accessory recommendations, and occasion ideas from our AI fashion expert
            </p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="py-12">
        <div class="max-w-4xl mx-auto px-4">
            <!-- Upload Card -->
            <div class="bg-white rounded-2xl shadow-2xl overflow-hidden fade-in-up">
                <div class="bg-gradient-to-r from-pink-600 to-purple-600 px-8 py-6">
                    <h2 class="text-2xl font-bold text-white flex items-center">
                        <i class="fas fa-upload mr-3"></i>
                        Upload Your Outfit Image
                    </h2>
                    <p class="text-white text-opacity-90 mt-2">Share a photo of your outfit and let AI work its magic</p>
                </div>

                <form action="" method="post" enctype="multipart/form-data" class="p-8">
                    <!-- Upload Area -->
                    <div class="upload-area rounded-xl p-12 text-center mb-6">
                        <div class="mb-4">
                            <i class="fas fa-cloud-upload-alt text-6xl text-gray-400"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-700 mb-2">
                            Choose an image or drag it here
                        </h3>
                        <p class="text-gray-500 mb-4">
                            JPEG or PNG • Maximum 5MB
                        </p>
                        <label class="inline-block">
                            <input 
                                type="file" 
                                name="outfit_image" 
                                accept="image/jpeg,image/png" 
                                required 
                                class="hidden" 
                                id="fileInput"
                                onchange="updateFileName(this)"
                            >
                            <span class="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-xl font-semibold cursor-pointer hover:shadow-lg transition transform hover:scale-105 inline-flex items-center">
                                <i class="fas fa-folder-open mr-2"></i>
                                Browse Files
                            </span>
                        </label>
                        <div id="fileName" class="mt-4 text-sm text-gray-600 font-medium"></div>
                    </div>

                    <!-- File Requirements -->
                    <div class="bg-blue-50 rounded-xl p-4 mb-6">
                        <h4 class="font-semibold text-blue-900 mb-2 flex items-center">
                            <i class="fas fa-info-circle mr-2"></i>
                            Upload Requirements
                        </h4>
                        <ul class="text-sm text-blue-800 space-y-1">
                            <li><i class="fas fa-check text-blue-600 mr-2"></i>Accepted formats: JPEG, PNG</li>
                            <li><i class="fas fa-check text-blue-600 mr-2"></i>Maximum file size: 5MB</li>
                            <li><i class="fas fa-check text-blue-600 mr-2"></i>Clear, well-lit photos work best</li>
                            <li><i class="fas fa-check text-blue-600 mr-2"></i>Full outfit visible for better suggestions</li>
                        </ul>
                    </div>

                    <!-- Submit Button -->
                    <button 
                        type="submit" 
                        class="btn-primary w-full text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center"
                    >
                        <i class="fas fa-magic mr-2"></i>
                        Get AI Styling Suggestions
                    </button>
                </form>
            </div>

            <!-- Success Result -->
            <?php if (!empty($responseText)): ?>
                <div class="mt-8 result-card">
                    <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl shadow-xl overflow-hidden border-2 border-green-200">
                        <div class="bg-gradient-to-r from-green-500 to-emerald-600 px-8 py-6">
                            <h2 class="text-2xl font-bold text-white flex items-center">
                                <i class="fas fa-check-circle mr-3"></i>
                                Your AI Styling Suggestions
                            </h2>
                            <p class="text-white text-opacity-90 mt-2">Here's what our AI fashion expert recommends</p>
                        </div>
                        
                        <div class="p-8">
                            <div class="bg-white rounded-xl p-6 shadow-md">
                                <?= formatResponse($responseText) ?>
                            </div>
                            
                            <div class="mt-6 flex flex-wrap gap-4">
                                <button 
                                    onclick="window.print()" 
                                    class="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition flex items-center"
                                >
                                    <i class="fas fa-print mr-2"></i>
                                    Print Suggestions
                                </button>
                                <button 
                                    onclick="location.reload()" 
                                    class="bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 transition flex items-center"
                                >
                                    <i class="fas fa-redo mr-2"></i>
                                    Try Another Outfit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Error Message -->
            <?php if (!empty($errorMessage)): ?>
                <div class="mt-8 result-card">
                    <div class="bg-red-50 rounded-2xl shadow-xl overflow-hidden border-2 border-red-200">
                        <div class="bg-gradient-to-r from-red-500 to-red-600 px-8 py-6">
                            <h2 class="text-2xl font-bold text-white flex items-center">
                                <i class="fas fa-exclamation-circle mr-3"></i>
                                Upload Error
                            </h2>
                        </div>
                        
                        <div class="p-8">
                            <div class="bg-white rounded-xl p-6 shadow-md">
                                <p class="text-red-700 font-semibold text-lg"><?= htmlspecialchars($errorMessage) ?></p>
                            </div>
                            
                            <div class="mt-6">
                                <button 
                                    onclick="location.reload()" 
                                    class="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition flex items-center"
                                >
                                    <i class="fas fa-redo mr-2"></i>
                                    Try Again
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- How It Works Card -->
            <div class="mt-8 bg-white rounded-2xl shadow-lg p-8 card-hover">
                <div class="flex items-start mb-6">
                    <div class="bg-gradient-to-br from-orange-500 to-red-500 rounded-full p-4 mr-4">
                        <i class="fas fa-question-circle text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-2">How It Works</h3>
                        <p class="text-gray-600">Our AI analyzes your outfit and provides expert styling advice</p>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-blue-100 to-blue-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <span class="text-2xl font-bold text-blue-700">1</span>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">Upload Photo</h4>
                        <p class="text-sm text-gray-600">Select a clear image of your outfit</p>
                    </div>
                    
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-purple-100 to-purple-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <span class="text-2xl font-bold text-purple-700">2</span>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">AI Analysis</h4>
                        <p class="text-sm text-gray-600">Our AI examines colors, style, and fit</p>
                    </div>
                    
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-green-100 to-green-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                            <span class="text-2xl font-bold text-green-700">3</span>
                        </div>
                        <h4 class="font-semibold text-gray-800 mb-2">Get Suggestions</h4>
                        <p class="text-sm text-gray-600">Receive personalized styling tips</p>
                    </div>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <a href="recommendation.php" class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl shadow-lg p-6 border-2 border-purple-200 hover:shadow-xl transition card-hover">
                    <div class="flex items-center">
                        <div class="bg-gradient-to-br from-purple-500 to-pink-500 rounded-full p-4 mr-4">
                            <i class="fas fa-tshirt text-white text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-gray-800">Get Outfit Ideas</h3>
                            <p class="text-gray-600 text-sm mt-1">Browse AI-generated recommendations</p>
                        </div>
                    </div>
                </a>
                
                <a href="forecast.php" class="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl shadow-lg p-6 border-2 border-blue-200 hover:shadow-xl transition card-hover">
                    <div class="flex items-center">
                        <div class="bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full p-4 mr-4">
                            <i class="fas fa-cloud-sun text-white text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-gray-800">Check Weather</h3>
                            <p class="text-gray-600 text-sm mt-1">Get weather-based clothing tips</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-white py-12 mt-16">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <i class="fas fa-cloud-sun-rain text-3xl text-purple-400 mr-3"></i>
                    <span class="text-xl font-bold">WeatherWear</span>
                </div>
                <p class="text-gray-400 text-sm">
                    © 2025 WeatherWear. All rights reserved.
                </p>
                <div class="flex space-x-4 mt-4 md:mt-0">
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition">
                        <i class="fab fa-facebook"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <script>
        function updateFileName(input) {
            const fileName = document.getElementById('fileName');
            if (input.files && input.files[0]) {
                const file = input.files[0];
                const fileSize = (file.size / 1024 / 1024).toFixed(2);
                fileName.innerHTML = `
                    <div class="inline-flex items-center bg-purple-100 text-purple-700 px-4 py-2 rounded-lg">
                        <i class="fas fa-file-image mr-2"></i>
                        <span class="font-medium">${file.name}</span>
                        <span class="ml-2 text-sm">(${fileSize} MB)</span>
                    </div>
                `;
            }
        }

        // Drag and drop functionality
        const uploadArea = document.querySelector('.upload-area');
        const fileInput = document.getElementById('fileInput');

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, preventDefaults, false);
        });

        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }

        ['dragenter', 'dragover'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.add('dragover');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            uploadArea.addEventListener(eventName, () => {
                uploadArea.classList.remove('dragover');
            }, false);
        });

        uploadArea.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            fileInput.files = files;
            updateFileName(fileInput);
        });

        // Click to upload
        uploadArea.addEventListener('click', (e) => {
            if (e.target === uploadArea || e.target.closest('.upload-area')) {
                fileInput.click();
            }
        });
    </script>
</body>
</html>