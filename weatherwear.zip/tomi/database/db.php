<?php
$host = "localhost";
$username= "tomi_user";
$password = "clothing_123";
$dbname = "tomi_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error){
    die('Connection Failed'. $conn->connect_error);
}

else{
    // print "Connection Successful";
}

?>