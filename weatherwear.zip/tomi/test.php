<?php
$apiKey = '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'; // Replace with your actual OpenAI API key

$url = 'https://api.openai.com/v1/chat/completions';

$headers = [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey
];

$postData = [
    'model' => 'gpt-3.5-turbo',
    'messages' => [
        ['role' => 'user', 'content' => 'Hello, OpenAI!']
    ],
    'max_tokens' => 50,
    'temperature' => 0.7
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
} else {
    $responseData = json_decode($response, true);
    echo "✅ API key is valid. Response:\n";
    print_r($responseData);
}

curl_close($ch);
?>
